import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Bot, Eye, EyeOff } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "@/lib/api";

export default function Login() {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await api.login({ email, password });
      if (response.success && response.token) {
        localStorage.setItem("auth_token", response.token);
        navigate("/dashboard");
      }
    } catch (error) {
      alert(error instanceof Error ? error.message : "Đăng nhập thất bại");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background flex items-center justify-center p-4 relative overflow-hidden">
      {/* NEO Grid Background */}
      <div className="absolute inset-0 neo-grid opacity-30"></div>

      {/* Floating NEO orbs */}
      <div
        className="absolute top-20 left-20 w-64 h-64 rounded-full"
        style={{
          background:
            "radial-gradient(circle, hsl(var(--neo-cyan)) 0%, transparent 70%)",
        }}
      ></div>
      <div
        className="absolute bottom-20 right-20 w-80 h-80 rounded-full"
        style={{
          background:
            "radial-gradient(circle, hsl(var(--neo-purple)) 0%, transparent 70%)",
        }}
      ></div>
      <div
        className="absolute top-40 right-40 w-48 h-48 rounded-full"
        style={{
          background:
            "radial-gradient(circle, hsl(var(--neo-pink)) 0%, transparent 70%)",
        }}
      ></div>

      {/* Scanning line effect */}
      <div
        className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-transparent via-cyan-400 to-transparent opacity-60 animate-pulse"
        style={{ animation: "neo-scan 8s linear infinite" }}
      ></div>

      <div className="w-full max-w-md relative z-10">
        {/* NEO Logo */}
        <div className="text-center mb-8">
          <Link
            to="/"
            className="inline-flex items-center space-x-3 p-4 rounded-2xl neo-card"
          >
            <div className="relative">
              <Bot className="h-10 w-10 text-cyan-400" />
              <div className="absolute inset-0 neo-glow">
                <Bot className="h-10 w-10 text-cyan-400 opacity-50" />
              </div>
            </div>
            <div className="text-left">
              <span className="block text-2xl font-bold neo-text neo-mono">
                ChatBot AI
              </span>
              <span className="block text-sm text-cyan-400 vietnamese-text">
                by Plugai.top
              </span>
            </div>
            <div className="flex flex-col space-y-1">
              <div className="neo-led neo-led-cyan"></div>
              <div className="neo-led neo-led-purple"></div>
              <div className="neo-led neo-led-pink"></div>
            </div>
          </Link>
        </div>

        <Card className="neo-card shadow-2xl border-0 relative overflow-hidden">
          {/* Card inner glow */}
          <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 via-transparent to-purple-500/5 pointer-events-none"></div>

          <CardHeader className="text-center space-y-3 relative z-10">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <div className="neo-led neo-led-cyan w-2 h-2"></div>
              <CardTitle className="text-2xl font-bold neo-text vietnamese-text">
                🔐 Đăng nhập hệ thống
              </CardTitle>
              <div className="neo-led neo-led-purple w-2 h-2"></div>
            </div>
            <CardDescription className="text-muted-foreground vietnamese-text">
              🚀 Đăng nhập để quản lý chatbot AI của bạn
            </CardDescription>
          </CardHeader>

          <CardContent className="relative z-10">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-3">
                <Label
                  htmlFor="email"
                  className="text-cyan-300 vietnamese-text flex items-center space-x-2"
                >
                  <span>📧</span>
                  <span>Email đăng nhập</span>
                </Label>
                <div className="relative group">
                  <Input
                    id="email"
                    type="email"
                    placeholder="admin@plugai.top"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="h-12 bg-background/50 border-cyan-500/30 text-foreground placeholder:text-muted-foreground focus:border-cyan-400 focus:ring-cyan-400 neo-mono"
                  />
                  <div className="absolute inset-0 rounded-md bg-gradient-to-r from-cyan-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
                </div>
              </div>

              <div className="space-y-3">
                <Label
                  htmlFor="password"
                  className="text-cyan-300 vietnamese-text flex items-center space-x-2"
                >
                  <span>🔑</span>
                  <span>Mật khẩu bảo mật</span>
                </Label>
                <div className="relative group">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="h-12 pr-12 bg-background/50 border-cyan-500/30 text-foreground placeholder:text-muted-foreground focus:border-cyan-400 focus:ring-cyan-400 neo-mono"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent text-cyan-400 hover:text-cyan-300"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                  <div className="absolute inset-0 rounded-md bg-gradient-to-r from-cyan-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <Link
                  to="/forgot-password"
                  className="text-sm text-cyan-400 hover:text-cyan-300 hover:underline vietnamese-text transition-colors"
                >
                  🔄 Quên mật khẩu?
                </Link>
              </div>

              <Button
                type="submit"
                className="w-full h-12 neo-button text-black font-semibold neo-mono relative overflow-hidden group"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center space-x-3">
                    <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                    <span className="vietnamese-text">🔄 Đang xác thực...</span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2">
                    <span className="vietnamese-text">
                      🚀 Đăng nhập hệ thống
                    </span>
                  </div>
                )}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-sm text-muted-foreground vietnamese-text">
                Chưa có tài khoản?{" "}
                <Link
                  to="/register"
                  className="neo-text hover:underline font-medium transition-all"
                >
                  🎯 Đăng ký ngay
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Admin Portal Link */}
        <Card className="mt-6 neo-card relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-red-500/10 via-transparent to-orange-500/10"></div>
          <CardContent className="pt-4 relative z-10">
            <p className="text-sm text-center">
              <Link
                to="/admin-login"
                className="text-red-400 hover:text-red-300 font-medium hover:underline flex items-center justify-center space-x-2 vietnamese-text transition-colors"
              >
                <span>🔱</span>
                <span>Truy cập Admin Portal</span>
                <div className="neo-led neo-led-pink w-1.5 h-1.5"></div>
              </Link>
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
