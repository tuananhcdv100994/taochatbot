import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Shield, Eye, EyeOff, Zap } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "@/lib/api";

export default function AdminLogin() {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await api.login({ email, password });
      if (response.success && response.token) {
        localStorage.setItem("auth_token", response.token);
        // Check if user is admin, redirect to admin dashboard
        const user = await api.getCurrentUser();
        if (user.role === "admin") {
          navigate("/admin");
        } else {
          navigate("/dashboard");
        }
      }
    } catch (error) {
      alert(error instanceof Error ? error.message : "Đăng nhập thất bại");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background flex items-center justify-center p-4 relative overflow-hidden">
      {/* NEO Grid Background */}
      <div className="absolute inset-0 neo-grid opacity-30"></div>

      {/* Floating NEO orbs */}
      <div
        className="absolute top-20 left-20 w-64 h-64 rounded-full"
        style={{
          background:
            "radial-gradient(circle, hsl(var(--neo-cyan)) 0%, transparent 70%)",
        }}
      ></div>
      <div
        className="absolute bottom-20 right-20 w-80 h-80 rounded-full"
        style={{
          background:
            "radial-gradient(circle, hsl(var(--neo-purple)) 0%, transparent 70%)",
        }}
      ></div>
      <div
        className="absolute top-40 right-40 w-48 h-48 rounded-full"
        style={{
          background:
            "radial-gradient(circle, hsl(var(--neo-pink)) 0%, transparent 70%)",
        }}
      ></div>

      {/* Scanning line effect */}
      <div
        className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-transparent via-cyan-400 to-transparent opacity-60 animate-pulse"
        style={{ animation: "neo-scan 8s linear infinite" }}
      ></div>

      <div className="w-full max-w-md relative z-10">
        {/* NEO Admin Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center space-x-3 p-4 rounded-2xl neo-card">
            <div className="relative">
              <Shield className="h-10 w-10 text-red-400" />
              <div className="absolute inset-0 neo-glow">
                <Shield className="h-10 w-10 text-red-400 opacity-50" />
              </div>
            </div>
            <div>
              <span className="text-3xl font-bold neo-text neo-mono">
                Admin Portal
              </span>
              <div className="flex items-center justify-center space-x-1 mt-1">
                <Zap className="h-3 w-3 text-yellow-400 animate-pulse" />
                <span className="text-xs text-cyan-400 font-medium vietnamese-text">
                  AI-POWERED
                </span>
                <Zap className="h-3 w-3 text-yellow-400 animate-pulse" />
              </div>
            </div>
            <div className="flex flex-col space-y-1">
              <div className="neo-led neo-led-cyan"></div>
              <div className="neo-led neo-led-purple"></div>
              <div className="neo-led neo-led-pink"></div>
            </div>
          </div>
        </div>

        <Card className="neo-card shadow-2xl border-0 relative overflow-hidden">
          {/* Card glow effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-red-500/10 via-transparent to-orange-500/10"></div>

          <CardHeader className="text-center space-y-3 relative z-10">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <div className="neo-led neo-led-cyan w-2 h-2"></div>
              <CardTitle className="text-2xl font-bold neo-text vietnamese-text">
                🔱 Admin Access
              </CardTitle>
              <div className="neo-led neo-led-purple w-2 h-2"></div>
            </div>
            <CardDescription className="text-muted-foreground vietnamese-text">
              🔐 Cổng truy cập quản trị bảo mật
            </CardDescription>
          </CardHeader>

          <CardContent className="relative z-10">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-purple-200">
                  Admin Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="admin@system.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="h-12 bg-slate-800/50 border-purple-500/30 text-white placeholder:text-purple-300/50 focus:border-purple-400 focus:ring-purple-400"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-purple-200">
                  Admin Password
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter secure password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="h-12 pr-12 bg-slate-800/50 border-purple-500/30 text-white placeholder:text-purple-300/50 focus:border-purple-400 focus:ring-purple-400"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent text-purple-300 hover:text-purple-200"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full h-12 bg-gradient-to-r from-purple-600 via-purple-700 to-blue-600 hover:from-purple-700 hover:via-purple-800 hover:to-blue-700 text-white font-semibold relative overflow-hidden group"
                disabled={isLoading}
              >
                {/* Button glow effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-purple-400 to-blue-400 opacity-0 group-hover:opacity-20 transition-opacity"></div>

                {isLoading ? (
                  <div className="flex items-center space-x-2">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Authenticating...</span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2">
                    <Shield className="h-4 w-4" />
                    <span>Secure Access</span>
                  </div>
                )}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <Link
                to="/login"
                className="text-sm text-purple-300 hover:text-purple-200 transition-colors"
              >
                ← Back to User Login
              </Link>
            </div>
          </CardContent>
        </Card>

        {/* Security notice */}
        <Card className="mt-4 bg-slate-900/60 border border-amber-500/30 backdrop-blur-sm">
          <CardContent className="pt-4">
            <p className="text-xs text-amber-300 text-center flex items-center justify-center space-x-2">
              <Zap className="h-3 w-3" />
              <span>Protected by advanced security protocols</span>
              <Zap className="h-3 w-3" />
            </p>
          </CardContent>
        </Card>
      </div>

      <style jsx>{`
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
      `}</style>
    </div>
  );
}
