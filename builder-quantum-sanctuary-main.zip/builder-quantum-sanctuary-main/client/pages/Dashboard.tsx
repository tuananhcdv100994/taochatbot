import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Bot as BotIcon,
  Plus,
  Settings,
  Eye,
  Code,
  MoreHorizontal,
  MessageCircle,
  Users,
  Crown,
  LogOut,
  Edit,
  Trash2,
  Shield,
  User as UserIcon,
  Phone,
  Mail,
  Calendar,
  Zap,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "@/lib/api";
import { User, Bot } from "@shared/api";
import UpgradeModal from "@/components/UpgradeModal";

export default function Dashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState<User | null>(null);
  const [bots, setBots] = useState<Bot[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [userData, botsData] = await Promise.all([
        api.getCurrentUser(),
        api.getBots(),
      ]);
      setUser(userData);
      setBots(botsData);
    } catch (error) {
      console.error("Failed to load data:", error);
      // If auth fails, redirect to login
      localStorage.removeItem("auth_token");
      navigate("/login");
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await api.logout();
    } catch (error) {
      console.error("Logout error:", error);
    }
    navigate("/");
  };

  const handleDeleteBot = async (botId: string) => {
    if (confirm("Bạn có chắc muốn xóa chatbot này?")) {
      try {
        await api.deleteBot(botId);
        setBots(bots.filter((bot) => bot.id !== botId));
      } catch (error) {
        alert("Không thể xóa chatbot");
      }
    }
  };

  const getStyleLabel = (style: string) => {
    const styles: { [key: string]: string } = {
      friendly: "Thân thiện",
      professional: "Chuyên nghiệp",
      casual: "Thoải mái",
      helpful: "Hỗ trợ",
    };
    return styles[style] || style;
  };

  const getGenderLabel = (gender: string) => {
    const genders: { [key: string]: string } = {
      male: "Nam",
      female: "Nữ",
      neutral: "Trung tính",
    };
    return genders[gender] || gender;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-accent/10 to-primary/5 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
          <p>Đang tải dữ liệu...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-blue-50 vietnamese-text">
      {/* Navigation */}
      <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <BotIcon className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold ai-text font-['Inter','system-ui','sans-serif']">
              ChatBot AI by Plugai.top
            </span>
          </div>

          <div className="flex items-center space-x-4">
            <Badge
              className={
                user?.plan === "pro"
                  ? "bg-gradient-to-r from-yellow-500 to-orange-500 text-white border-0"
                  : "bg-gradient-to-r from-blue-500 to-purple-500 text-white border-0"
              }
            >
              <Crown className="w-3 h-3 mr-1" />
              <span className="vietnamese-text">
                {user?.plan === "pro" ? "👑 Gói Pro" : "🆓 Gói Miễn phí"}
              </span>
            </Badge>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="relative h-10 w-10 rounded-full ai-glow"
                >
                  <Avatar className="h-10 w-10 border-2 border-purple-300">
                    <AvatarImage src="/avatars/01.png" alt="Avatar" />
                    <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white font-bold">
                      {user?.fullName
                        ?.split(" ")
                        .map((n) => n[0])
                        .join("")
                        .toUpperCase() || "U"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                className="w-72 bg-white/95 backdrop-blur border-purple-200 shadow-xl"
                align="end"
                forceMount
              >
                <DropdownMenuLabel className="font-normal p-4">
                  <div className="flex items-center space-x-3 mb-3">
                    <Avatar className="h-12 w-12 border-2 border-purple-300">
                      <AvatarImage src="/avatars/01.png" alt="Avatar" />
                      <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white font-bold text-lg">
                        {user?.fullName
                          ?.split(" ")
                          .map((n) => n[0])
                          .join("")
                          .toUpperCase() || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="text-base font-semibold leading-none vietnamese-text mb-1">
                        {user?.fullName}
                      </p>
                      <Badge
                        className={
                          user?.plan === "pro"
                            ? "bg-gradient-to-r from-yellow-500 to-orange-500 text-white text-xs"
                            : "bg-gradient-to-r from-blue-500 to-purple-500 text-white text-xs"
                        }
                      >
                        <Crown className="w-3 h-3 mr-1" />
                        {user?.plan === "pro" ? "👑 Pro" : "🆓 Free"}
                      </Badge>
                    </div>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center space-x-2 text-gray-600">
                      <Mail className="h-4 w-4 text-blue-500" />
                      <span className="vietnamese-text">{user?.email}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-gray-600">
                      <Phone className="h-4 w-4 text-green-500" />
                      <span className="vietnamese-text">
                        {user?.phoneNumber || "Chưa cập nhật"}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2 text-gray-600">
                      <Calendar className="h-4 w-4 text-purple-500" />
                      <span className="vietnamese-text">
                        Tham gia:{" "}
                        {user?.createdAt
                          ? new Date(user.createdAt).toLocaleDateString("vi-VN")
                          : "--"}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2 text-gray-600">
                      <UserIcon className="h-4 w-4 text-orange-500" />
                      <span className="vietnamese-text">
                        Loại tài khoản:{" "}
                        {user?.role === "admin" ? "🔑 Admin" : "👤 Người dùng"}
                      </span>
                    </div>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="vietnamese-text">
                  <Settings className="mr-2 h-4 w-4 text-gray-500" />
                  <span>⚙️ Cài đặt tài khoản</span>
                </DropdownMenuItem>
                {user?.role === "admin" && (
                  <DropdownMenuItem asChild>
                    <Link to="/admin" className="vietnamese-text">
                      <Shield className="mr-2 h-4 w-4 text-red-500" />
                      <span>🔐 Trang quản trị Admin</span>
                    </Link>
                  </DropdownMenuItem>
                )}
                <UpgradeModal>
                  <DropdownMenuItem
                    onSelect={(e) => e.preventDefault()}
                    className="vietnamese-text"
                  >
                    <Crown className="mr-2 h-4 w-4 text-yellow-500" />
                    <span>🚀 Nâng cấp lên Pro</span>
                  </DropdownMenuItem>
                </UpgradeModal>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={handleLogout}
                  className="vietnamese-text text-red-600"
                >
                  <LogOut className="mr-2 h-4 w-4 text-red-500" />
                  <span>😪 Đăng xuất tài khoản</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
            <p className="text-muted-foreground">
              Quản lý và theo dõi các chatbot của bạn
            </p>
          </div>
          <Link to="/create-bot">
            <Button
              size="lg"
              className="bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 mt-4 md:mt-0"
            >
              <Plus className="w-4 h-4 mr-2" />
              Tạo ChatBot mới
            </Button>
          </Link>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Tổng số ChatBot
              </CardTitle>
              <BotIcon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {bots.length}
                {user?.plan === "free" ? "/2" : ""}
              </div>
              <p className="text-xs text-muted-foreground">
                {user?.plan === "free" && bots.length >= 2
                  ? "Đã sử dụng hết quota miễn phí"
                  : user?.plan === "pro"
                    ? "Không giới hạn"
                    : `Còn ${1 - bots.length} chatbot`}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Tin nhắn tháng này
              </CardTitle>
              <MessageCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {bots.reduce((sum, bot) => sum + bot.messageCount, 0)}
              </div>
              <p className="text-xs text-muted-foreground">Tổng số tin nhắn</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Người dùng</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">425</div>
              <p className="text-xs text-muted-foreground">
                +7% so với tháng trước
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Chatbots List */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Danh sách ChatBot</h2>
            {user?.plan === "free" && bots.length >= 1 && (
              <UpgradeModal>
                <Button variant="outline">
                  <Crown className="w-4 h-4 mr-2" />
                  Nâng cấp để tạo thêm
                </Button>
              </UpgradeModal>
            )}
          </div>

          {bots.length === 0 ? (
            <Card className="p-12 text-center">
              <BotIcon className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">
                Chưa có ChatBot nào
              </h3>
              <p className="text-muted-foreground mb-6">
                Tạo ChatBot đầu tiên để bắt đầu hỗ trợ khách hàng
              </p>
              <Link to="/create-bot">
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Tạo ChatBot đầu tiên
                </Button>
              </Link>
            </Card>
          ) : (
            <div className="grid gap-4">
              {bots.map((bot) => (
                <Card
                  key={bot.id}
                  className="hover:shadow-lg transition-shadow"
                >
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                          <BotIcon className="w-6 h-6 text-primary" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{bot.name}</CardTitle>
                          <CardDescription>{bot.description}</CardDescription>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge
                          variant={
                            bot.status === "active" ? "default" : "secondary"
                          }
                        >
                          {bot.status === "active" ? "Hoạt động" : "Tạm dừng"}
                        </Badge>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem asChild>
                              <Link to={`/bot/${bot.id}/settings`}>
                                <Eye className="mr-2 h-4 w-4" />
                                Xem trước
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild>
                              <Link to={`/bot/${bot.id}/settings`}>
                                <Edit className="mr-2 h-4 w-4" />
                                Cài đặt
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild>
                              <Link to={`/bot/${bot.id}/settings`}>
                                <Code className="mr-2 h-4 w-4" />
                                Lấy mã nhúng
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild>
                              <Link to={`/bot/${bot.id}/customers`}>
                                <Users className="mr-2 h-4 w-4" />
                                Quản lý khách hàng
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              className="text-destructive"
                              onClick={() => handleDeleteBot(bot.id)}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Xóa
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Tin nhắn:</span>
                        <div className="font-medium">{bot.messageCount}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">
                          Phong cách:
                        </span>
                        <div className="font-medium">{bot.style}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">
                          Giới tính:
                        </span>
                        <div className="font-medium">{bot.gender}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Tạo lúc:</span>
                        <div className="font-medium">
                          {new Date(bot.createdAt).toLocaleDateString("vi-VN")}
                        </div>
                      </div>
                    </div>

                    <div className="flex space-x-2 mt-4">
                      <Link to={`/bot/${bot.id}/settings`}>
                        <Button variant="outline" size="sm">
                          <Eye className="w-4 h-4 mr-2" />
                          Xem trước
                        </Button>
                      </Link>
                      <Link to={`/bot/${bot.id}/settings`}>
                        <Button variant="outline" size="sm">
                          <Settings className="w-4 h-4 mr-2" />
                          Cài đặt
                        </Button>
                      </Link>
                      <Link to={`/bot/${bot.id}/settings`}>
                        <Button variant="outline" size="sm">
                          <Code className="w-4 h-4 mr-2" />
                          Mã nhúng
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Upgrade Banner */}
        {bots.length >= 2 && (
          <Card className="mt-8 bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold mb-2">
                    Nâng cấp lên Pro để tạo kh��ng giới hạn ChatBot
                  </h3>
                  <p className="text-muted-foreground">
                    Tạo thêm chatbot, không giới hạn tin nhắn và nhiều tính năng
                    pro khác
                  </p>
                </div>
                <div className="flex flex-col space-y-2">
                  <UpgradeModal>
                    <Button className="bg-gradient-to-r from-primary to-primary/80">
                      <Crown className="w-4 h-4 mr-2" />
                      Nâng cấp ngay
                    </Button>
                  </UpgradeModal>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-primary border-primary"
                    onClick={() => window.open("tel:0792762794", "_self")}
                  >
                    📞 Liên hệ: 0792762794
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
