import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Bot,
  ArrowLeft,
  Copy,
  Key,
  Code,
  AlertTriangle,
  CheckCircle,
  ExternalLink,
  Save,
  MessageSquare,
  Send,
  RefreshCw,
  Globe,
  AlertCircle,
} from "lucide-react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { api } from "@/lib/api";
import { Bot as BotType } from "@shared/api";

export default function BotSettings() {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [bot, setBot] = useState<BotType | null>(null);
  const [loading, setLoading] = useState(true);
  const [embedCode, setEmbedCode] = useState("");
  const [iframeEmbedCode, setIframeEmbedCode] = useState("");
  const [selectedEmbedType, setSelectedEmbedType] = useState<
    "script" | "iframe"
  >("script");
  const [apiKey, setApiKey] = useState("");
  const [websiteUrl, setWebsiteUrl] = useState("");
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [checking, setChecking] = useState(false);
  const [testMessage, setTestMessage] = useState("");
  const [chatHistory, setChatHistory] = useState<
    Array<{ message: string; response: string; timestamp: string }>
  >([]);
  const [embedStatus, setEmbedStatus] = useState<{
    status: "active" | "warning" | "inactive";
    message: string;
    lastChecked?: string;
  } | null>(null);

  useEffect(() => {
    if (id) {
      loadBotData();
    }
  }, [id]);

  const loadBotData = async () => {
    try {
      const bots = await api.getBots();
      const currentBot = bots.find((b) => b.id === id);
      if (currentBot) {
        setBot(currentBot);
        setApiKey(currentBot.apiKey || "");
        setWebsiteUrl(currentBot.websiteUrl || "");
        const embedResponse = await api.getBotEmbedCode(id!);
        setEmbedCode(embedResponse.embedCode);

        // Generate iframe embed code
        const serverUrl = window.location.origin;
        const iframeCode = `<!-- ChatBot AI Widget (iframe) -->
<iframe 
  id="chatbot-ai-iframe"
  src="${serverUrl}/iframe-widget?botId=${currentBot.id}&botName=${encodeURIComponent(currentBot.name)}&primaryColor=${encodeURIComponent(currentBot.primaryColor)}&theme=${currentBot.theme}&position=${currentBot.position}&apiKey=YOUR_CHATGPT_API_KEY"
  style="position: fixed; bottom: 0; right: 0; width: 400px; height: 600px; border: none; z-index: 999999; background: transparent;"
  allow="microphone; camera"
  loading="lazy">
</iframe>`;
        setIframeEmbedCode(iframeCode);
      } else {
        navigate("/dashboard");
      }
    } catch (error) {
      console.error("Failed to load bot:", error);
      navigate("/dashboard");
    } finally {
      setLoading(false);
    }
  };

  const handleSaveApiKey = async () => {
    if (!bot) return;
    setSaving(true);
    try {
      await api.updateBot(bot.id, { apiKey, websiteUrl });
      setBot({ ...bot, apiKey, websiteUrl });
      alert("Cài đặt đã được lưu!");

      // Regenerate embed codes with correct API key
      const embedResponse = await api.getBotEmbedCode(bot.id);
      setEmbedCode(
        embedResponse.embedCode.replace("YOUR_CHATGPT_API_KEY", apiKey),
      );

      // Update iframe embed code
      const serverUrl = window.location.origin;
      const iframeCode = `<!-- ChatBot AI Widget (iframe) -->
<iframe 
  id="chatbot-ai-iframe"
  src="${serverUrl}/iframe-widget?botId=${bot.id}&botName=${encodeURIComponent(bot.name)}&primaryColor=${encodeURIComponent(bot.primaryColor)}&theme=${bot.theme}&position=${bot.position}&apiKey=${apiKey}"
  style="position: fixed; bottom: 0; right: 0; width: 400px; height: 600px; border: none; z-index: 999999; background: transparent;"
  allow="microphone; camera"
  loading="lazy">
</iframe>`;
      setIframeEmbedCode(iframeCode);
    } catch (error) {
      alert("Không thể lưu cài đặt");
    } finally {
      setSaving(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert("Đã sao chép vào clipboard!");
  };

  const handleTestChatbot = async () => {
    if (!bot || !testMessage.trim()) return;

    setTesting(true);
    try {
      const response = await api.testChatbot({
        message: testMessage,
        botId: bot.id,
        knowledge: bot.knowledge,
        apiKey: apiKey || bot.apiKey || "",
      });

      if (response.success && response.response) {
        setChatHistory((prev) => [
          ...prev,
          {
            message: testMessage,
            response: response.response!,
            timestamp: response.timestamp || new Date().toISOString(),
          },
        ]);
        setTestMessage("");
      } else {
        alert(response.error || "Có lỗi xảy ra khi test chatbot");
      }
    } catch (error) {
      alert(error instanceof Error ? error.message : "Không thể test chatbot");
    } finally {
      setTesting(false);
    }
  };

  const handleCheckEmbedStatus = async () => {
    if (!bot) return;

    setChecking(true);
    try {
      const response = await api.checkEmbedStatus({
        websiteUrl: websiteUrl || bot.websiteUrl || "",
        botId: bot.id,
        apiKey: apiKey || bot.apiKey || "",
      });

      if (response.success) {
        setEmbedStatus({
          status: response.status,
          message: response.message,
          lastChecked: response.lastChecked,
        });
      }
    } catch (error) {
      alert("Không thể kiểm tra trạng thái embed");
    } finally {
      setChecking(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-accent/10 to-primary/5 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
          <p>Đang tải dữ liệu...</p>
        </div>
      </div>
    );
  }

  if (!bot) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-accent/10 to-primary/5 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Không tìm thấy chatbot</h2>
          <Link to="/dashboard">
            <Button>Quay về Dashboard</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-accent/10 to-primary/5">
      {/* Navigation */}
      <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/dashboard" className="flex items-center space-x-2">
            <Bot className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              ChatBot AI
            </span>
          </Link>

          <div className="flex items-center space-x-4">
            <Badge variant="outline">{bot.name}</Badge>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center mb-8">
          <Link to="/dashboard">
            <Button variant="ghost" size="sm" className="mr-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Dashboard
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold">Cài đặt ChatBot</h1>
            <p className="text-muted-foreground">{bot.name}</p>
          </div>
        </div>

        <Tabs defaultValue="api" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="api">
              <Key className="w-4 h-4 mr-2" />
              API & URL
            </TabsTrigger>
            <TabsTrigger value="test">
              <MessageSquare className="w-4 h-4 mr-2" />
              Test Chat
            </TabsTrigger>
            <TabsTrigger value="embed">
              <Code className="w-4 h-4 mr-2" />
              Mã nhúng
            </TabsTrigger>
            <TabsTrigger value="preview">
              <Bot className="w-4 h-4 mr-2" />
              Xem trước
            </TabsTrigger>
          </TabsList>

          {/* API Integration Tab */}
          <TabsContent value="api" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Key className="w-5 h-5 mr-2" />
                  Cấu hình API và Website
                </CardTitle>
                <CardDescription>
                  Cung cấp API Key và URL website để chatbot hoạt động chính xác
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle>Lưu ý bảo mật</AlertTitle>
                  <AlertDescription>
                    API Key sẽ được mã hóa và lưu trữ an toàn. Không chia sẻ API
                    Key với người khác.
                  </AlertDescription>
                </Alert>

                <div className="space-y-2">
                  <Label htmlFor="apiKey">OpenAI API Key</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="apiKey"
                      type="password"
                      placeholder="sk-..."
                      value={apiKey}
                      onChange={(e) => setApiKey(e.target.value)}
                      className="font-mono"
                    />
                    <Button
                      onClick={handleSaveApiKey}
                      disabled={saving}
                      className="px-6"
                    >
                      {saving ? (
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : (
                        <Save className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                  {bot.apiKey && (
                    <div className="flex items-center text-sm text-green-600">
                      <CheckCircle className="w-4 h-4 mr-1" />
                      API Key đã được cấu hình
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="websiteUrl">URL Website (Tùy chọn)</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="websiteUrl"
                      type="url"
                      placeholder="https://yourwebsite.com"
                      value={websiteUrl}
                      onChange={(e) => setWebsiteUrl(e.target.value)}
                      className="font-mono"
                    />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    URL này sẽ được sử dụng để kiểm tra trạng thái mã nhúng
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Test Chat Tab */}
          <TabsContent value="test" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageSquare className="w-5 h-5 mr-2" />
                  Test ChatBot
                </CardTitle>
                <CardDescription>
                  Thử nghiệm chatbot trước khi đưa vào sử dụng
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {!apiKey && !bot.apiKey && (
                  <Alert>
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Chưa cấu hình API Key</AlertTitle>
                    <AlertDescription>
                      Vui lòng cấu hình OpenAI API Key trong tab "API & URL" để
                      test chatbot.
                    </AlertDescription>
                  </Alert>
                )}

                {/* Chat History */}
                <div className="space-y-4">
                  <div className="border rounded-lg p-4 bg-muted/30 min-h-[300px] max-h-[400px] overflow-y-auto">
                    {chatHistory.length === 0 ? (
                      <div className="text-center text-muted-foreground py-8">
                        <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
                        <p>Chưa có cuộc hội thoại nào</p>
                        <p className="text-sm">
                          Nhập tin nhắn bên dưới để bắt đầu test
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {chatHistory.map((chat, index) => (
                          <div key={index} className="space-y-3">
                            {/* User message */}
                            <div className="flex justify-end">
                              <div className="bg-primary text-primary-foreground rounded-lg px-4 py-2 max-w-[80%]">
                                <p className="text-sm">{chat.message}</p>
                                <p className="text-xs opacity-70 mt-1">
                                  {new Date(chat.timestamp).toLocaleTimeString(
                                    "vi-VN",
                                  )}
                                </p>
                              </div>
                            </div>

                            {/* Bot response */}
                            <div className="flex justify-start">
                              <div className="bg-white border rounded-lg px-4 py-2 max-w-[80%]">
                                <p className="text-sm">{chat.response}</p>
                                <p className="text-xs text-muted-foreground mt-1">
                                  ChatBot AI
                                </p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Input */}
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Nhập tin nhắn để test chatbot..."
                      value={testMessage}
                      onChange={(e) => setTestMessage(e.target.value)}
                      onKeyPress={(e) => {
                        if (e.key === "Enter" && !testing) {
                          handleTestChatbot();
                        }
                      }}
                      disabled={testing || (!apiKey && !bot.apiKey)}
                    />
                    <Button
                      onClick={handleTestChatbot}
                      disabled={
                        testing ||
                        !testMessage.trim() ||
                        (!apiKey && !bot.apiKey)
                      }
                    >
                      {testing ? (
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : (
                        <Send className="w-4 h-4" />
                      )}
                    </Button>
                  </div>

                  {chatHistory.length > 0 && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setChatHistory([])}
                    >
                      Xóa lịch sử chat
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Embed Code Tab */}
          <TabsContent value="embed" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Code className="w-5 h-5 mr-2" />
                    Mã nhúng website - 2 Tùy chọn
                  </div>
                  <div className="flex items-center space-x-2">
                    {embedStatus && (
                      <Badge
                        variant={
                          embedStatus.status === "active"
                            ? "default"
                            : embedStatus.status === "warning"
                              ? "secondary"
                              : "destructive"
                        }
                        className={
                          embedStatus.status === "active"
                            ? "bg-green-100 text-green-800"
                            : embedStatus.status === "warning"
                              ? "bg-yellow-100 text-yellow-800"
                              : "bg-red-100 text-red-800"
                        }
                      >
                        {embedStatus.status === "active" && "🟢 Hoạt động"}
                        {embedStatus.status === "warning" && "🟡 Cảnh báo"}
                        {embedStatus.status === "inactive" &&
                          "🔴 Không hoạt động"}
                      </Badge>
                    )}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleCheckEmbedStatus}
                      disabled={checking || !websiteUrl}
                    >
                      {checking ? (
                        <RefreshCw className="w-4 h-4 animate-spin" />
                      ) : (
                        <RefreshCw className="w-4 h-4" />
                      )}
                      Kiểm tra
                    </Button>
                  </div>
                </CardTitle>
                <CardDescription>
                  Chọn loại mã nhúng phù hợp với website của bạn. Widget Script
                  (khuyên dùng) có performance tốt hơn, Iframe dùng khi có
                  conflict.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {!apiKey && !bot.apiKey && (
                  <Alert>
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Chưa cấu hình API Key</AlertTitle>
                    <AlertDescription>
                      Mã nhúng chưa hoàn chỉnh. Vui lòng cấu hình OpenAI API Key
                      trong tab "API & URL" trước.
                    </AlertDescription>
                  </Alert>
                )}

                {!websiteUrl && (
                  <Alert>
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Chưa có URL website</AlertTitle>
                    <AlertDescription>
                      Vui lòng nhập URL website trong tab "API & URL" để có thể
                      kiểm tra trạng thái embed.
                    </AlertDescription>
                  </Alert>
                )}

                {/* Embed Type Selector */}
                <div className="flex space-x-4 p-4 bg-muted/30 rounded-lg">
                  <button
                    onClick={() => setSelectedEmbedType("script")}
                    className={`flex-1 p-4 rounded-lg border-2 transition-all ${
                      selectedEmbedType === "script"
                        ? "border-primary bg-primary/10"
                        : "border-muted-foreground/20 hover:border-muted-foreground/40"
                    }`}
                  >
                    <div className="text-center">
                      <div className="text-2xl mb-2">📦</div>
                      <h3 className="font-semibold">Widget Script</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        Khuyên dùng - Performance tốt nhất
                      </p>
                      <div className="mt-2 text-xs text-green-600">
                        ✅ Native JS • ✅ SEO friendly • ✅ Tối ưu tốc độ
                      </div>
                    </div>
                  </button>

                  <button
                    onClick={() => setSelectedEmbedType("iframe")}
                    className={`flex-1 p-4 rounded-lg border-2 transition-all ${
                      selectedEmbedType === "iframe"
                        ? "border-primary bg-primary/10"
                        : "border-muted-foreground/20 hover:border-muted-foreground/40"
                    }`}
                  >
                    <div className="text-center">
                      <div className="text-2xl mb-2">🖼️</div>
                      <h3 className="font-semibold">Iframe Widget</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        Backup - An toàn khi có conflict
                      </p>
                      <div className="mt-2 text-xs text-blue-600">
                        ✅ Isolated • ✅ No conflict • ✅ Cross-domain safe
                      </div>
                    </div>
                  </button>
                </div>

                <div className="space-y-2">
                  <Label className="flex items-center justify-between">
                    <span>
                      {selectedEmbedType === "script"
                        ? "📦 Widget Script Code"
                        : "🖼️ Iframe Embed Code"}
                    </span>
                    <Badge variant="outline">
                      {selectedEmbedType === "script"
                        ? "Khuyên dùng"
                        : "Backup option"}
                    </Badge>
                  </Label>
                  <div className="relative">
                    <Textarea
                      value={
                        selectedEmbedType === "script"
                          ? embedCode.replace(
                              "YOUR_CHATGPT_API_KEY",
                              apiKey || bot.apiKey || "YOUR_CHATGPT_API_KEY",
                            )
                          : iframeEmbedCode.replace(
                              "YOUR_CHATGPT_API_KEY",
                              apiKey || bot.apiKey || "YOUR_CHATGPT_API_KEY",
                            )
                      }
                      readOnly
                      rows={selectedEmbedType === "script" ? 20 : 10}
                      className="font-mono text-sm resize-none"
                    />
                    <Button
                      size="sm"
                      variant="outline"
                      className="absolute top-2 right-2"
                      onClick={() => {
                        const codeToScript =
                          selectedEmbedType === "script"
                            ? embedCode.replace(
                                "YOUR_CHATGPT_API_KEY",
                                apiKey || bot.apiKey || "YOUR_CHATGPT_API_KEY",
                              )
                            : iframeEmbedCode.replace(
                                "YOUR_CHATGPT_API_KEY",
                                apiKey || bot.apiKey || "YOUR_CHATGPT_API_KEY",
                              );
                        copyToClipboard(codeToScript);
                      }}
                    >
                      <Copy className="w-4 h-4 mr-1" />
                      Copy
                    </Button>
                  </div>
                </div>

                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertTitle>
                    Hướng dẫn tích hợp{" "}
                    {selectedEmbedType === "script"
                      ? "Widget Script"
                      : "Iframe"}
                  </AlertTitle>
                  <AlertDescription>
                    {selectedEmbedType === "script" ? (
                      <ol className="list-decimal list-inside space-y-1 mt-2">
                        <li>Sao chép toàn bộ mã Script ở trên</li>
                        <li>
                          Dán vào website của bạn, ngay trước thẻ đóng{" "}
                          <code className="bg-muted px-1 rounded">
                            &lt;/body&gt;
                          </code>
                        </li>
                        <li>
                          Widget sẽ tự động load và xuất hiện ở góc đã chọn
                        </li>
                        <li>Không cần cấu hình thêm, hoạt động ngay lập tức</li>
                        <li>
                          Performance tốt nhất, không bị chặn popup/iframe
                        </li>
                      </ol>
                    ) : (
                      <ol className="list-decimal list-inside space-y-1 mt-2">
                        <li>Sao chép toàn bộ mã Iframe ở trên</li>
                        <li>
                          Dán vào website của bạn, ngay trước thẻ đóng{" "}
                          <code className="bg-muted px-1 rounded">
                            &lt;/body&gt;
                          </code>
                        </li>
                        <li>
                          Iframe sẽ load independent, tránh conflict CSS/JS
                        </li>
                        <li>
                          An toàn hơn khi website có nhiều thư viện phức tạp
                        </li>
                        <li>Có thể chậm hơn một chút do phải load iframe</li>
                      </ol>
                    )}
                  </AlertDescription>
                </Alert>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2 flex items-center">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Test Widget Script
                    </h4>
                    <p className="text-sm text-blue-800 mb-2">
                      Test widget script với nhiều cấu hình:
                    </p>
                    <a
                      href={`${window.location.origin}/widget-test`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline text-sm font-mono"
                    >
                      {window.location.origin}/widget-test
                    </a>
                  </div>

                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2 flex items-center">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Test Iframe Widget
                    </h4>
                    <p className="text-sm text-green-800 mb-2">
                      Test iframe widget với UI đẹp:
                    </p>
                    <a
                      href={`${window.location.origin}/iframe-test`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-green-600 hover:underline text-sm font-mono"
                    >
                      {window.location.origin}/iframe-test
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Preview Tab */}
          <TabsContent value="preview" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Bot className="w-5 h-5 mr-2" />
                  Xem trước ChatBot
                </CardTitle>
                <CardDescription>
                  Giao diện chatbot sẽ hiển thị như thế này trên website
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="border-2 border-dashed border-muted-foreground/30 rounded-lg p-8 min-h-[400px] relative bg-muted/20">
                  <div className="text-center text-muted-foreground">
                    <Bot className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <h3 className="text-lg font-semibold mb-2">
                      Demo ChatBot Widget
                    </h3>
                    <p className="text-sm">
                      Widget sẽ xuất hiện ở vị trí{" "}
                      <strong>
                        {bot.position === "bottom-right"
                          ? "dưới phải"
                          : bot.position === "bottom-left"
                            ? "dưới trái"
                            : bot.position === "top-right"
                              ? "trên phải"
                              : "trên trái"}
                      </strong>{" "}
                      của website
                    </p>
                  </div>

                  {/* Mock widget */}
                  <div
                    className={`absolute w-16 h-16 rounded-full shadow-lg flex items-center justify-center cursor-pointer hover:scale-110 transition-transform ${
                      bot.position === "bottom-right"
                        ? "bottom-4 right-4"
                        : bot.position === "bottom-left"
                          ? "bottom-4 left-4"
                          : bot.position === "top-right"
                            ? "top-4 right-4"
                            : "top-4 left-4"
                    }`}
                    style={{ backgroundColor: bot.primaryColor }}
                  >
                    <Bot className="w-8 h-8 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
