import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Bot, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

export default function Terms() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-accent/10 to-primary/5">
      {/* Navigation */}
      <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <Bot className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              ChatBot AI
            </span>
          </Link>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center mb-8">
            <Link to="/">
              <Button variant="ghost" size="sm" className="mr-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Trang chủ
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold">Điều khoản sử dụng</h1>
              <p className="text-muted-foreground">
                Điều khoản và điều kiện sử dụng dịch vụ ChatBot AI
              </p>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Điều khoản sử dụng dịch vụ ChatBot AI</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-sm max-w-none space-y-6">
              <section>
                <h3 className="text-lg font-semibold mb-3">
                  1. Chấp nhận điều khoản
                </h3>
                <p className="text-muted-foreground">
                  Bằng việc truy cập và sử dụng dịch vụ ChatBot AI, bạn đồng ý
                  tuân thủ và bị ràng buộc bởi các điều khoản và điều kiện được
                  nêu trong tài liệu này.
                </p>
              </section>

              <section>
                <h3 className="text-lg font-semibold mb-3">2. Mô tả dịch vụ</h3>
                <p className="text-muted-foreground">
                  ChatBot AI cung cấp nền tảng tạo và quản lý chatbot AI tự động
                  cho website. Dịch vụ bao gồm:
                </p>
                <ul className="list-disc list-inside text-muted-foreground ml-4 space-y-1">
                  <li>Tạo chatbot với giao diện tùy chỉnh</li>
                  <li>Tích hợp API ChatGPT</li>
                  <li>Mã nhúng website</li>
                  <li>Quản lý và theo dõi chatbot</li>
                </ul>
              </section>

              <section>
                <h3 className="text-lg font-semibold mb-3">
                  3. Tài khoản người dùng
                </h3>
                <p className="text-muted-foreground">
                  Bạn chịu trách nhiệm duy trì tính bảo mật của tài khoản và mật
                  khẩu. Bạn đồng ý chấp nhận trách nhiệm đối với tất cả các hoạt
                  động diễn ra dưới tài khoản của mình.
                </p>
              </section>

              <section>
                <h3 className="text-lg font-semibold mb-3">4. Gói dịch vụ</h3>
                <p className="text-muted-foreground">
                  <strong>Gói miễn phí:</strong> Tối đa 1 chatbot, 1000 tin
                  nhắn/tháng
                  <br />
                  <strong>Gói Pro:</strong> Không giới hạn chatbot và tin nhắn,
                  299k VNĐ/tháng
                </p>
              </section>

              <section>
                <h3 className="text-lg font-semibold mb-3">
                  5. Chính sách thanh toán
                </h3>
                <p className="text-muted-foreground">
                  Phí dịch vụ được tính theo tháng và cần được thanh toán trước.
                  Chúng tôi có quyền tạm dừng dịch vụ nếu không nhận được thanh
                  toán đúng hạn.
                </p>
              </section>

              <section>
                <h3 className="text-lg font-semibold mb-3">
                  6. Giới hạn trách nhiệm
                </h3>
                <p className="text-muted-foreground">
                  ChatBot AI không chịu trách nhiệm về bất kỳ thiệt hại nào phát
                  sinh từ việc sử dụng dịch vụ, bao gồm nhưng không giới hạn ở
                  việc mất dữ liệu, gián đoạn kinh doanh hoặc mất lợi nhuận.
                </p>
              </section>

              <section>
                <h3 className="text-lg font-semibold mb-3">
                  7. Thay đổi điều khoản
                </h3>
                <p className="text-muted-foreground">
                  Chúng tôi có quyền thay đổi các điều khoản này bất kỳ lúc nào.
                  Các thay đổi sẽ có hiệu lực ngay khi được đăng tải trên
                  website.
                </p>
              </section>

              <section>
                <h3 className="text-lg font-semibold mb-3">8. Liên hệ</h3>
                <p className="text-muted-foreground">
                  Nếu bạn có bất kỳ câu hỏi nào về điều khoản sử dụng, vui lòng
                  liên hệ:
                  <br />
                  <strong>Hotline:</strong> 0792762794
                  <br />
                  <strong>Email:</strong> support@chatbotai.com
                </p>
              </section>

              <div className="bg-muted/50 p-4 rounded-lg mt-6">
                <p className="text-sm text-muted-foreground">
                  <strong>Cập nhật lần cu���i:</strong>{" "}
                  {new Date().toLocaleDateString("vi-VN")}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
