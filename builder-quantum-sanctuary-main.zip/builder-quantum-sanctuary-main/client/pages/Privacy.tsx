import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Bot, ArrowLeft, Shield, Eye, Lock } from "lucide-react";
import { Link } from "react-router-dom";

export default function Privacy() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-accent/10 to-primary/5">
      {/* Navigation */}
      <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <Bot className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              ChatBot AI
            </span>
          </Link>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center mb-8">
            <Link to="/">
              <Button variant="ghost" size="sm" className="mr-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Trang chủ
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold">Chính sách bảo mật</h1>
              <p className="text-muted-foreground">
                Cam kết bảo vệ thông tin cá nhân của bạn
              </p>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="w-5 h-5 mr-2" />
                Chính sách bảo mật ChatBot AI
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-sm max-w-none space-y-6">
              <section>
                <h3 className="text-lg font-semibold mb-3 flex items-center">
                  <Eye className="w-4 h-4 mr-2" />
                  1. Thông tin chúng tôi thu thập
                </h3>
                <p className="text-muted-foreground mb-3">
                  Chúng tôi thu thập các thông tin sau:
                </p>
                <ul className="list-disc list-inside text-muted-foreground ml-4 space-y-1">
                  <li>
                    <strong>Thông tin tài khoản:</strong> Họ tên, email, mật
                    khẩu
                  </li>
                  <li>
                    <strong>Thông tin chatbot:</strong> Tên, mô tả, cài đặt
                    chatbot
                  </li>
                  <li>
                    <strong>Dữ liệu sử dụng:</strong> Số lượng tin nhắn, thời
                    gian sử dụng
                  </li>
                  <li>
                    <strong>Thông tin thanh toán:</strong> Gói dịch vụ đã đăng
                    ký
                  </li>
                </ul>
              </section>

              <section>
                <h3 className="text-lg font-semibold mb-3 flex items-center">
                  <Lock className="w-4 h-4 mr-2" />
                  2. Cách chúng tôi sử dụng thông tin
                </h3>
                <p className="text-muted-foreground mb-3">
                  Thông tin của bạn được sử dụng để:
                </p>
                <ul className="list-disc list-inside text-muted-foreground ml-4 space-y-1">
                  <li>Cung cấp và duy trì dịch vụ ChatBot AI</li>
                  <li>Xử lý thanh toán và quản lý tài khoản</li>
                  <li>Gửi thông báo quan trọng về dịch vụ</li>
                  <li>Cải thiện chất lượng dịch vụ</li>
                  <li>Hỗ trợ khách hàng khi cần thiết</li>
                </ul>
              </section>

              <section>
                <h3 className="text-lg font-semibold mb-3">
                  3. Bảo mật dữ liệu
                </h3>
                <div className="bg-green-50 p-4 rounded-lg mb-4">
                  <h4 className="font-medium text-green-800 mb-2">
                    Cam kết bảo mật
                  </h4>
                  <ul className="text-green-700 text-sm space-y-1">
                    <li>✓ Mã hóa SSL/TLS cho tất cả dữ liệu truyền tải</li>
                    <li>✓ Mật khẩu được hash với thuật toán bảo mật cao</li>
                    <li>✓ API Key được mã hóa trước khi lưu trữ</li>
                    <li>✓ Backup dữ liệu định kỳ để đảm bảo an toàn</li>
                  </ul>
                </div>
              </section>

              <section>
                <h3 className="text-lg font-semibold mb-3">
                  4. Chia sẻ thông tin với bên thứ ba
                </h3>
                <p className="text-muted-foreground">
                  Chúng tôi <strong>KHÔNG</strong> bán, cho thuê hoặc chia sẻ
                  thông tin cá nhân của bạn với bên thứ ba, ngoại trừ:
                </p>
                <ul className="list-disc list-inside text-muted-foreground ml-4 space-y-1 mt-2">
                  <li>Khi có yêu cầu pháp lý từ cơ quan chức năng</li>
                  <li>Với sự đồng ý rõ ràng của bạn</li>
                  <li>
                    Với các nhà cung cấp dịch vụ tin cậy (OpenAI API) chỉ để vận
                    hành dịch vụ
                  </li>
                </ul>
              </section>

              <section>
                <h3 className="text-lg font-semibold mb-3">
                  5. Quyền của người dùng
                </h3>
                <p className="text-muted-foreground mb-3">Bạn có quyền:</p>
                <ul className="list-disc list-inside text-muted-foreground ml-4 space-y-1">
                  <li>Truy cập và chỉnh sửa thông tin cá nhân</li>
                  <li>Yêu cầu xóa tài khoản và dữ liệu</li>
                  <li>Xuất dữ liệu chatbot của bạn</li>
                  <li>Từ chối nhận email marketing</li>
                  <li>Khiếu nại về việc xử lý dữ liệu</li>
                </ul>
              </section>

              <section>
                <h3 className="text-lg font-semibold mb-3">
                  6. Cookie và tracking
                </h3>
                <p className="text-muted-foreground">
                  Chúng tôi sử dụng cookie để ghi nhớ đăng nhập và cải thiện
                  trải nghiệm người dùng. Bạn có thể tắt cookie trong trình
                  duyệt nhưng một số tính năng có thể không hoạt động.
                </p>
              </section>

              <section>
                <h3 className="text-lg font-semibold mb-3">
                  7. Lưu trữ dữ liệu
                </h3>
                <p className="text-muted-foreground">
                  Dữ liệu của bạn được lưu trữ tại các máy chủ bảo mật. Chúng
                  tôi chỉ giữ dữ liệu trong thời gian cần thiết để cung cấp dịch
                  vụ hoặc theo quy định pháp luật.
                </p>
              </section>

              <section>
                <h3 className="text-lg font-semibold mb-3">
                  8. Thay đổi chính sách
                </h3>
                <p className="text-muted-foreground">
                  Chúng tôi có thể cập nhật chính sách bảo mật này. Mọi thay đổi
                  quan trọng sẽ được thông báo qua email hoặc trên website.
                </p>
              </section>

              <section>
                <h3 className="text-lg font-semibold mb-3">9. Liên hệ</h3>
                <p className="text-muted-foreground">
                  Nếu bạn có bất kỳ câu hỏi nào về chính sách bảo mật:
                  <br />
                  <strong>Hotline:</strong> 0792762794
                  <br />
                  <strong>Email:</strong> privacy@chatbotai.com
                </p>
              </section>

              <div className="bg-blue-50 p-4 rounded-lg mt-6">
                <p className="text-sm text-blue-800">
                  <strong>Cam kết:</strong> Chúng tôi luôn đặt quyền riêng tư
                  của bạn lên hàng đầu và không ngừng cải thiện các biện pháp
                  bảo mật.
                </p>
              </div>

              <div className="bg-muted/50 p-4 rounded-lg mt-6">
                <p className="text-sm text-muted-foreground">
                  <strong>Cập nhật lần cuối:</strong>{" "}
                  {new Date().toLocaleDateString("vi-VN")}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
