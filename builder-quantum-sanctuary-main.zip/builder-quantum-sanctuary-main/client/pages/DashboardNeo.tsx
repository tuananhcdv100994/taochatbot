import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Bot as BotIcon,
  Plus,
  Settings,
  Eye,
  Code,
  MoreHorizontal,
  MessageCircle,
  Users,
  Crown,
  LogOut,
  Edit,
  Trash2,
  Shield,
  UserIcon as User,
  Phone,
  Mail,
  Calendar,
  Zap,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "@/lib/api";
import { User as UserType, Bot } from "@shared/api";
import UpgradeModal from "@/components/UpgradeModal";

export default function DashboardNeo() {
  const navigate = useNavigate();
  const [user, setUser] = useState<UserType | null>(null);
  const [bots, setBots] = useState<Bot[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [userData, botsData] = await Promise.all([
        api.getCurrentUser(),
        api.getBots(),
      ]);
      setUser(userData);
      setBots(botsData);
    } catch (error) {
      console.error("Failed to load data:", error);
      localStorage.removeItem("auth_token");
      navigate("/login");
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await api.logout();
    } catch (error) {
      console.error("Logout error:", error);
    }
    navigate("/");
  };

  const handleDeleteBot = async (botId: string) => {
    if (confirm("Bạn có chắc muốn xóa chatbot này?")) {
      try {
        await api.deleteBot(botId);
        setBots(bots.filter((bot) => bot.id !== botId));
      } catch (error) {
        alert("Không thể xóa chatbot");
      }
    }
  };

  const getStyleLabel = (style: string) => {
    const styles: { [key: string]: string } = {
      friendly: "Thân thiện",
      professional: "Chuyên nghiệp",
      casual: "Thoải mái",
      helpful: "Hỗ trợ",
    };
    return styles[style] || style;
  };

  const getGenderLabel = (gender: string) => {
    const genders: { [key: string]: string } = {
      male: "Nam",
      female: "Nữ",
      neutral: "Trung tính",
    };
    return genders[gender] || gender;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-background flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 neo-grid opacity-20"></div>
        <div className="text-center relative z-10">
          <div className="neo-glow w-16 h-16 border-2 border-cyan-500 border-t-purple-500 rounded-full animate-spin mx-auto mb-6"></div>
          <p className="text-foreground text-lg font-medium vietnamese-text">
            🔄 Đang tải dữ liệu hệ thống...
          </p>
          <div className="flex items-center justify-center space-x-2 mt-4">
            <div className="neo-led neo-led-cyan"></div>
            <div className="neo-led neo-led-purple"></div>
            <div className="neo-led neo-led-pink"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background vietnamese-text relative overflow-hidden">
      {/* NEO Grid Background */}
      <div className="absolute inset-0 neo-grid opacity-20"></div>

      {/* Floating NEO orbs */}
      <div
        className="absolute top-10 left-10 w-96 h-96 rounded-full"
        style={{
          background:
            "radial-gradient(circle, hsl(var(--neo-cyan)) 0%, transparent 70%)",
        }}
      ></div>
      <div
        className="absolute bottom-10 right-10 w-80 h-80 rounded-full"
        style={{
          background:
            "radial-gradient(circle, hsl(var(--neo-purple)) 0%, transparent 70%)",
        }}
      ></div>

      {/* NEO Navigation */}
      <nav className="border-b border-cyan-500/30 bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/5 via-transparent to-purple-500/5"></div>
        <div className="container mx-auto px-4 py-4 flex items-center justify-between relative z-10">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <BotIcon className="h-8 w-8 text-cyan-400" />
              <div className="absolute inset-0 neo-glow">
                <BotIcon className="h-8 w-8 text-cyan-400 opacity-50" />
              </div>
            </div>
            <span className="text-2xl font-bold neo-text neo-mono">
              ChatBot AI
            </span>
            <span className="text-sm text-cyan-400 vietnamese-text">
              by Plugai.top
            </span>
          </div>

          <div className="flex items-center space-x-4">
            <Badge
              className={
                user?.plan === "pro"
                  ? "neo-button text-black border-0"
                  : "bg-background/50 border border-cyan-500/30 text-cyan-400"
              }
            >
              <Crown className="w-3 h-3 mr-1" />
              <span className="vietnamese-text">
                {user?.plan === "pro" ? "👑 Gói Pro" : "🆓 Gói Miễn phí"}
              </span>
            </Badge>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="relative h-10 w-10 rounded-full neo-glow"
                >
                  <Avatar className="h-10 w-10 border-2 border-cyan-400">
                    <AvatarImage src="/avatars/01.png" alt="Avatar" />
                    <AvatarFallback className="bg-gradient-to-r from-cyan-500 to-purple-500 text-white font-bold neo-mono">
                      {user?.fullName
                        ?.split(" ")
                        .map((n) => n[0])
                        .join("")
                        .toUpperCase() || "U"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="absolute -bottom-1 -right-1 neo-led neo-led-green w-4 h-4 border-2 border-background flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                className="w-72 neo-card shadow-xl"
                align="end"
                forceMount
              >
                <DropdownMenuLabel className="font-normal p-4">
                  <div className="flex items-center space-x-3 mb-3">
                    <Avatar className="h-12 w-12 border-2 border-cyan-400 neo-glow">
                      <AvatarImage src="/avatars/01.png" alt="Avatar" />
                      <AvatarFallback className="bg-gradient-to-r from-cyan-500 to-purple-500 text-white font-bold text-lg neo-mono">
                        {user?.fullName
                          ?.split(" ")
                          .map((n) => n[0])
                          .join("")
                          .toUpperCase() || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="text-base font-semibold leading-none vietnamese-text mb-1 text-foreground">
                        {user?.fullName}
                      </p>
                      <Badge
                        className={
                          user?.plan === "pro"
                            ? "neo-button text-black text-xs"
                            : "bg-background/50 border border-cyan-500/30 text-cyan-400 text-xs"
                        }
                      >
                        <Crown className="w-3 h-3 mr-1" />
                        {user?.plan === "pro" ? "👑 Pro" : "🆓 Free"}
                      </Badge>
                    </div>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center space-x-2 text-muted-foreground">
                      <Mail className="h-4 w-4 text-cyan-400" />
                      <span className="vietnamese-text neo-mono">
                        {user?.email}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2 text-muted-foreground">
                      <Phone className="h-4 w-4 text-green-400" />
                      <span className="vietnamese-text">
                        {user?.phoneNumber || "Chưa cập nhật"}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2 text-muted-foreground">
                      <Calendar className="h-4 w-4 text-purple-400" />
                      <span className="vietnamese-text">
                        Tham gia:{" "}
                        {user?.createdAt
                          ? new Date(user.createdAt).toLocaleDateString("vi-VN")
                          : "--"}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2 text-muted-foreground">
                      <User className="h-4 w-4 text-orange-400" />
                      <span className="vietnamese-text">
                        Loại tài khoản:{" "}
                        {user?.role === "admin" ? "🔑 Admin" : "👤 Người dùng"}
                      </span>
                    </div>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="vietnamese-text">
                  <Settings className="mr-2 h-4 w-4 text-gray-500" />
                  <span>⚙️ Cài đặt tài khoản</span>
                </DropdownMenuItem>
                {user?.role === "admin" && (
                  <DropdownMenuItem asChild>
                    <Link to="/admin" className="vietnamese-text">
                      <Shield className="mr-2 h-4 w-4 text-red-500" />
                      <span>🔐 Trang quản trị Admin</span>
                    </Link>
                  </DropdownMenuItem>
                )}
                <UpgradeModal>
                  <DropdownMenuItem
                    onSelect={(e) => e.preventDefault()}
                    className="vietnamese-text"
                  >
                    <Crown className="mr-2 h-4 w-4 text-yellow-500" />
                    <span>🚀 Nâng cấp lên Pro</span>
                  </DropdownMenuItem>
                </UpgradeModal>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={handleLogout}
                  className="vietnamese-text text-red-600"
                >
                  <LogOut className="mr-2 h-4 w-4 text-red-500" />
                  <span>😴 Đăng xuất tài khoản</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8 relative z-10">
        {/* NEO Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="flex space-x-1">
              <div className="neo-led neo-led-cyan w-2 h-2"></div>
              <div className="neo-led neo-led-purple w-2 h-2"></div>
              <div className="neo-led neo-led-pink w-2 h-2"></div>
            </div>
            <h1 className="text-4xl font-bold neo-text vietnamese-text neo-mono">
              🤖 Dashboard AI
            </h1>
            <div className="flex space-x-1">
              <div className="neo-led neo-led-pink w-2 h-2"></div>
              <div className="neo-led neo-led-purple w-2 h-2"></div>
              <div className="neo-led neo-led-cyan w-2 h-2"></div>
            </div>
          </div>
          <p className="text-muted-foreground text-lg vietnamese-text">
            🚀 Quản lý chatbot AI thông minh của bạn
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="neo-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-cyan-400 vietnamese-text">
                🤖 ChatBot đã tạo
              </CardTitle>
              <BotIcon className="h-4 w-4 text-cyan-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground neo-mono">
                {bots.length}
              </div>
              <p className="text-xs text-muted-foreground vietnamese-text">
                📊 Tối đa {user?.plan === "pro" ? "∞" : "1"} chatbot
              </p>
            </CardContent>
          </Card>

          <Card className="neo-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-purple-400 vietnamese-text">
                💬 Tin nhắn hôm nay
              </CardTitle>
              <MessageCircle className="h-4 w-4 text-purple-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground neo-mono">
                {user?.messageCount || 0}
              </div>
              <p className="text-xs text-muted-foreground vietnamese-text">
                📈 Tăng 12% so với hôm qua
              </p>
            </CardContent>
          </Card>

          <Card className="neo-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-pink-400 vietnamese-text">
                👥 Người dùng tương tác
              </CardTitle>
              <Users className="h-4 w-4 text-pink-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground neo-mono">
                0
              </div>
              <p className="text-xs text-muted-foreground vietnamese-text">
                🌟 Chức năng sắp ra mắt
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Chatbots Section */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-bold neo-text vietnamese-text">
                🤖 Danh sách ChatBot
              </h2>
              <p className="text-muted-foreground vietnamese-text">
                Quản lý và tùy chỉnh các chatbot AI của bạn
              </p>
            </div>
            <Link to="/create-bot">
              <Button className="neo-button text-black font-semibold">
                <Plus className="mr-2 h-4 w-4" />
                <span className="vietnamese-text">🚀 Tạo ChatBot mới</span>
              </Button>
            </Link>
          </div>

          {bots.length === 0 ? (
            <Card className="neo-card text-center py-12">
              <CardContent>
                <BotIcon className="mx-auto h-12 w-12 text-cyan-400 mb-4" />
                <h3 className="text-lg font-semibold mb-2 text-foreground vietnamese-text">
                  🎯 Chưa có ChatBot nào
                </h3>
                <p className="text-muted-foreground mb-4 vietnamese-text">
                  Tạo chatbot AI đầu tiên để bắt đầu hành trình của bạn
                </p>
                <Link to="/create-bot">
                  <Button className="neo-button text-black font-semibold">
                    <Plus className="mr-2 h-4 w-4" />
                    <span className="vietnamese-text">
                      🚀 Tạo ChatBot đầu tiên
                    </span>
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {bots.map((bot) => (
                <Card key={bot.id} className="neo-card relative">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div className="flex items-center space-x-2">
                        <BotIcon className="h-5 w-5 text-cyan-400" />
                        <CardTitle className="text-lg text-foreground vietnamese-text">
                          {bot.name}
                        </CardTitle>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            className="h-8 w-8 p-0 text-muted-foreground hover:text-foreground"
                          >
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent className="neo-card" align="end">
                          <DropdownMenuItem asChild>
                            <Link
                              to={`/bot/${bot.id}/settings`}
                              className="vietnamese-text"
                            >
                              <Edit className="mr-2 h-4 w-4" />
                              ⚙️ Chỉnh sửa
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => handleDeleteBot(bot.id)}
                            className="text-red-400 vietnamese-text"
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            🗑️ Xóa bot
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    <CardDescription className="text-muted-foreground vietnamese-text">
                      {bot.description || "🤖 ChatBot AI thông minh"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground vietnamese-text">
                          🎭 Phong cách:
                        </span>
                        <Badge className="bg-background/50 border border-cyan-500/30 text-cyan-400">
                          {getStyleLabel(bot.conversationStyle)}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground vietnamese-text">
                          👤 Giới tính:
                        </span>
                        <Badge className="bg-background/50 border border-purple-500/30 text-purple-400">
                          {getGenderLabel(bot.gender)}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground vietnamese-text">
                          🎨 Chủ đề:
                        </span>
                        <Badge className="bg-background/50 border border-pink-500/30 text-pink-400">
                          {bot.theme === "dark" ? "🌙 Tối" : "☀️ Sáng"}
                        </Badge>
                      </div>
                    </div>
                    <div className="mt-4 flex space-x-2">
                      <Link to={`/bot/${bot.id}/settings`} className="flex-1">
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
                        >
                          <Settings className="mr-2 h-4 w-4" />
                          <span className="vietnamese-text">⚙️ Cài đặt</span>
                        </Button>
                      </Link>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-purple-500/30 text-purple-400 hover:bg-purple-500/10"
                      >
                        <Code className="mr-2 h-4 w-4" />
                        <span className="vietnamese-text">📋 Embed</span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
