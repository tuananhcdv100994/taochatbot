import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Bot,
  Sparkles,
  Code,
  Users,
  Zap,
  Shield,
  MessageCircle,
  Settings,
  Palette,
  Download,
} from "lucide-react";
import { Link } from "react-router-dom";
import UpgradeModal from "@/components/UpgradeModal";

export default function Index() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-accent/10 to-primary/5">
      {/* Navigation */}
      <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Bot className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              ChatBot AI by Plugai.top
            </span>
          </div>
          <div className="hidden md:flex items-center space-x-6">
            <a
              href="#features"
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              Tính năng
            </a>
            <a
              href="#pricing"
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              Bảng giá
            </a>
            <a
              href="#contact"
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              Liên hệ
            </a>
          </div>
          <div className="flex items-center space-x-3">
            <Link to="/login">
              <Button variant="ghost" size="sm">
                Đăng nhập
              </Button>
            </Link>
            <Link to="/register">
              <Button
                size="sm"
                className="bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70"
              >
                Tạo tài khoản
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <div className="max-w-4xl mx-auto">
          <Badge
            variant="secondary"
            className="mb-6 bg-primary/10 text-primary border-primary/20"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            N��n tảng tạo ChatBot AI by Plugai.top thông minh
          </Badge>

          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-foreground via-primary to-foreground bg-clip-text text-transparent leading-tight">
            Tạo ChatBot AI by Plugai.top
            <br />
            <span className="text-primary">
              <p>trong vài phút</p>
            </span>
          </h1>

          <p className="text-xl text-white mb-8 max-w-2xl mx-auto leading-relaxed">
            Xây dựng chatbot thông minh cho website của bạn với công nghệ AI
            tiên tiến của PlugAi. Tùy chỉnh hoàn toàn giao diện, phong cách trả
            lời và tích hợp dễ dàng.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link to="/register">
              <Button
                size="lg"
                className="bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 text-lg px-8 py-6"
              >
                <Bot className="w-5 h-5 mr-2" />
                Tạo ChatBot miễn phí
              </Button>
            </Link>
            <Button variant="outline" size="lg" className="text-lg px-8 py-6">
              <MessageCircle className="w-5 h-5 mr-2" />
              Xem demo
            </Button>
          </div>

          <div className="mt-12 text-sm text-white">
            <p>Miễn phí tạo 1 chatbot Không cần thẻ tín dụng</p>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="container mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Tính năng nổi bật</h2>
          <p className="text-xl text-white max-w-2xl mx-auto">
            Tất cả các công cụ bạn cần để tạo ra chatbot AI hoàn hảo cho doanh
            nghiệp
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="relative overflow-hidden border-0 bg-gradient-to-br from-card to-card/50 shadow-lg hover:shadow-xl transition-all duration-300">
            <CardHeader>
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                <Bot className="w-6 h-6 text-primary" />
              </div>
              <CardTitle>AI Thông minh</CardTitle>
              <CardDescription>
                Tích hợp ChatGPT API để trả lời tự động chính xác và tự nhiên
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="relative overflow-hidden border-0 bg-gradient-to-br from-card to-card/50 shadow-lg hover:shadow-xl transition-all duration-300">
            <CardHeader>
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                <Palette className="w-6 h-6 text-primary" />
              </div>
              <CardTitle>Tùy chỉnh giao diện</CardTitle>
              <CardDescription>
                Thay đổi màu sắc, theme và giao diện để phù hợp với thương hiệu
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="relative overflow-hidden border-0 bg-gradient-to-br from-card to-card/50 shadow-lg hover:shadow-xl transition-all duration-300">
            <CardHeader>
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                <Settings className="w-6 h-6 text-primary" />
              </div>
              <CardTitle>Cá nhân hóa</CardTitle>
              <CardDescription>
                Chọn giới tính, phong cách tư vấn và thông tin riêng cho bot
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="relative overflow-hidden border-0 bg-gradient-to-br from-card to-card/50 shadow-lg hover:shadow-xl transition-all duration-300">
            <CardHeader>
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                <Code className="w-6 h-6 text-primary" />
              </div>
              <CardTitle>Mã nhúng dễ dàng</CardTitle>
              <CardDescription>
                Xuất code để tích hợp chatbot vào website chỉ với vài dòng code
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="relative overflow-hidden border-0 bg-gradient-to-br from-card to-card/50 shadow-lg hover:shadow-xl transition-all duration-300">
            <CardHeader>
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-primary" />
              </div>
              <CardTitle>Siêu nhanh</CardTitle>
              <CardDescription>
                Thời gian phản hồi dưới 1 giây với API tối ưu hóa hiệu suất
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="relative overflow-hidden border-0 bg-gradient-to-br from-card to-card/50 shadow-lg hover:shadow-xl transition-all duration-300">
            <CardHeader>
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 text-primary" />
              </div>
              <CardTitle>Bảo mật cao</CardTitle>
              <CardDescription>
                Mã hóa dữ liệu và bảo mật thông tin khách hàng tuyệt đối
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </section>

      {/* Pricing Section */}
      <section
        id="pricing"
        className="container mx-auto px-4 py-20 bg-muted/30"
      >
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Bảng giá đơn giản</h2>
          <p className="text-xl text-white">
            Bắt đầu miễn phí, nâng cấp khi cần
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <Card className="relative border-2 border-border">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Miễn phí</CardTitle>
              <CardDescription>Hoàn hảo để bắt đầu</CardDescription>
              <div className="text-4xl font-bold mt-4">₫0</div>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                <li className="flex items-center">
                  <Bot className="w-4 h-4 text-green-500 mr-3" />
                  Tối đa 1 chatbot
                </li>
                <li className="flex items-center">
                  <MessageCircle className="w-4 h-4 text-green-500 mr-3" />
                  1000 tin nhắn/tháng
                </li>
                <li className="flex items-center">
                  <Palette className="w-4 h-4 text-green-500 mr-3" />
                  Tùy chỉnh cơ bản
                </li>
                <li className="flex items-center">
                  <Download className="w-4 h-4 text-green-500 mr-3" />
                  Mã nhúng website
                </li>
              </ul>
              <Button className="w-full mt-6" variant="outline">
                Bắt đầu miễn phí
              </Button>
            </CardContent>
          </Card>

          <Card className="relative border-2 border-primary bg-gradient-to-br from-primary/5 to-primary/10">
            <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-primary">
              Phổ biến
            </Badge>
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Pro</CardTitle>
              <CardDescription>Cho doanh nghiệp phát triển</CardDescription>
              <div className="text-4xl font-bold mt-4">
                ₫299k<span className="text-lg font-normal">/tháng</span>
              </div>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                <li className="flex items-center">
                  <Bot className="w-4 h-4 text-green-500 mr-3" />
                  Không giới hạn chatbot
                </li>
                <li className="flex items-center">
                  <MessageCircle className="w-4 h-4 text-green-500 mr-3" />
                  Không giới hạn tin nhắn
                </li>
                <li className="flex items-center">
                  <Palette className="w-4 h-4 text-green-500 mr-3" />
                  Tùy chỉnh nâng cao
                </li>
                <li className="flex items-center">
                  <Users className="w-4 h-4 text-green-500 mr-3" />
                  Hỗ trợ ưu tiên
                </li>
              </ul>
              <UpgradeModal>
                <Button className="w-full mt-6 bg-gradient-to-r from-primary to-primary/80">
                  Nâng cấp ngay
                </Button>
              </UpgradeModal>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="container mx-auto px-4 py-20">
        <div className="text-center">
          <h2 className="text-4xl font-bold mb-4">Cần hỗ trợ?</h2>
          <p className="text-xl text-muted-foreground mb-8">
            Liên hệ với chúng tôi để được tư vấn và hỗ trợ
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
            >
              📞 Hotline: 0792762794
            </Button>
            <Button variant="outline" size="lg">
              📧 Email hỗ trợ
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-muted/30">
        <div className="container mx-auto px-4 py-12">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Bot className="h-6 w-6 text-primary" />
                <span className="text-lg font-bold">
                  {" "}
                  ChatBot AI by Plugai.top
                </span>
              </div>
              <p className="text-muted-foreground">
                Nền tảng tạo chatbot AI thông minh cho doanh nghiệp hiện đại.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Sản phẩm</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>Tạo ChatBot</li>
                <li>Tùy chỉnh giao diện</li>
                <li>Tích hợp website</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Hỗ trợ</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>Hướng dẫn sử dụng</li>
                <li>API Documentation</li>
                <li>Liên hệ</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Pháp lý</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>Điều khoản sử dụng</li>
                <li>Chính sách bảo mật</li>
                <li>Chính sách hoàn tiền</li>
              </ul>
            </div>
          </div>
          <div className="border-t mt-8 pt-8 text-center text-muted-foreground">
            <p>
              &copy; 2024 ChatBot AI của Plugai.top | Tất cả quyền được bảo lưu.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
