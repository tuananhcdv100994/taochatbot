import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Bot,
  ArrowLeft,
  ArrowRight,
  Check,
  User,
  MessageCircle,
  Palette,
  Settings,
  Code,
  Eye,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "@/lib/api";

interface BotData {
  name: string;
  description: string;
  knowledge: string;
  gender: "male" | "female" | "neutral";
  style: string;
  primaryColor: string;
  theme: "light" | "dark" | "auto";
  position: "bottom-right" | "bottom-left" | "top-right" | "top-left";
}

export default function CreateBot() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [botData, setBotData] = useState<BotData>({
    name: "",
    description: "",
    knowledge: "",
    gender: "neutral",
    style: "friendly",
    primaryColor: "#8b5cf6",
    theme: "light",
    position: "bottom-right",
  });

  const totalSteps = 5;
  const progress = (currentStep / totalSteps) * 100;

  const styles = [
    { id: "friendly", label: "Thân thiện", description: "Gần gũi, ấm áp" },
    {
      id: "professional",
      label: "Chuyên nghiệp",
      description: "Lịch sự, trang trọng",
    },
    { id: "casual", label: "Thoải mái", description: "Vui vẻ, tự nhiên" },
    { id: "helpful", label: "Hỗ trợ", description: "Tận tình, chi tiết" },
  ];

  const colors = [
    "#8b5cf6",
    "#3b82f6",
    "#10b981",
    "#f59e0b",
    "#ef4444",
    "#ec4899",
    "#6366f1",
    "#8b5cf6",
  ];

  const positions = [
    { id: "bottom-right", label: "Dưới phải", icon: "↘️" },
    { id: "bottom-left", label: "Dưới trái", icon: "↙️" },
    { id: "top-right", label: "Trên phải", icon: "↗️" },
    { id: "top-left", label: "Trên trái", icon: "↖️" },
  ];

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async () => {
    try {
      await api.createBot(botData);
      navigate("/dashboard");
    } catch (error) {
      alert(error instanceof Error ? error.message : "Không thể tạo chatbot");
    }
  };

  const updateBotData = (updates: Partial<BotData>) => {
    setBotData((prev) => ({ ...prev, ...updates }));
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 1:
        return botData.name.trim() !== "" && botData.description.trim() !== "";
      case 2:
        return botData.knowledge.trim() !== "";
      case 3:
        return true; // Gender selection has default
      case 4:
        return true; // Color and theme have defaults
      case 5:
        return true; // Position has default
      default:
        return false;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-accent/10 to-primary/5">
      {/* Navigation */}
      <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/dashboard" className="flex items-center space-x-2">
            <Bot className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              ChatBot AI
            </span>
          </Link>

          <div className="flex items-center space-x-4">
            <Badge variant="outline">
              Bước {currentStep} / {totalSteps}
            </Badge>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Tạo ChatBot mới</h1>
          <p className="text-muted-foreground">
            Thiết lập chatbot AI trong vài bước đơn giản
          </p>
        </div>

        {/* Progress */}
        <div className="max-w-2xl mx-auto mb-8">
          <Progress value={progress} className="h-2" />
          <div className="flex justify-between mt-2 text-sm text-muted-foreground">
            <span>Thông tin cơ bản</span>
            <span>Kiến thức</span>
            <span>Tính cách</span>
            <span>Giao diện</span>
            <span>Hoàn thành</span>
          </div>
        </div>

        {/* Steps */}
        <div className="max-w-2xl mx-auto">
          <Card className="shadow-lg">
            <CardHeader>
              <div className="flex items-center space-x-2">
                {currentStep === 1 && <Settings className="w-5 h-5" />}
                {currentStep === 2 && <MessageCircle className="w-5 h-5" />}
                {currentStep === 3 && <User className="w-5 h-5" />}
                {currentStep === 4 && <Palette className="w-5 h-5" />}
                {currentStep === 5 && <Eye className="w-5 h-5" />}
                <CardTitle>
                  {currentStep === 1 && "Thông tin cơ bản"}
                  {currentStep === 2 && "Kiến thức và dữ liệu"}
                  {currentStep === 3 && "Tính cách và phong cách"}
                  {currentStep === 4 && "Tùy chỉnh giao diện"}
                  {currentStep === 5 && "Xem trước và hoàn thành"}
                </CardTitle>
              </div>
              <CardDescription>
                {currentStep === 1 && "Đặt tên và mô tả cho chatbot của bạn"}
                {currentStep === 2 && "Cung cấp thông tin để chatbot học hỏi"}
                {currentStep === 3 && "Chọn giới tính và phong cách trả lời"}
                {currentStep === 4 && "Tùy chỉnh màu sắc và giao diện"}
                {currentStep === 5 && "Xem trước chatbot và hoàn thành tạo"}
              </CardDescription>
            </CardHeader>

            <CardContent className="space-y-6">
              {/* Step 1: Basic Info */}
              {currentStep === 1 && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Tên ChatBot *</Label>
                    <Input
                      id="name"
                      placeholder="VD: Customer Support Bot"
                      value={botData.name}
                      onChange={(e) => updateBotData({ name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Mô tả *</Label>
                    <Textarea
                      id="description"
                      placeholder="VD: Bot hỗ trợ khách hàng cho website bán hàng"
                      value={botData.description}
                      onChange={(e) =>
                        updateBotData({ description: e.target.value })
                      }
                      rows={3}
                    />
                  </div>
                </div>
              )}

              {/* Step 2: Knowledge */}
              {currentStep === 2 && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="knowledge">Thông tin và kiến thức *</Label>
                    <Textarea
                      id="knowledge"
                      placeholder="Nhập thông tin, câu hỏi thường gặp, sản phẩm, dịch vụ... để chatbot học hỏi và trả lời khách hàng một cách chính xác."
                      value={botData.knowledge}
                      onChange={(e) =>
                        updateBotData({ knowledge: e.target.value })
                      }
                      rows={8}
                      className="resize-none"
                    />
                    <p className="text-sm text-muted-foreground">
                      Càng nhiều thông tin, chatbot sẽ trả lời càng chính xác
                    </p>
                  </div>
                </div>
              )}

              {/* Step 3: Personality */}
              {currentStep === 3 && (
                <div className="space-y-6">
                  <div className="space-y-3">
                    <Label>Giới tính</Label>
                    <RadioGroup
                      value={botData.gender}
                      onValueChange={(value) =>
                        updateBotData({ gender: value as any })
                      }
                      className="flex space-x-6"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="male" id="male" />
                        <Label htmlFor="male">Nam</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="female" id="female" />
                        <Label htmlFor="female">Nữ</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="neutral" id="neutral" />
                        <Label htmlFor="neutral">Trung tính</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div className="space-y-3">
                    <Label>Phong cách trả lời</Label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {styles.map((style) => (
                        <Card
                          key={style.id}
                          className={`cursor-pointer transition-all hover:shadow-md ${
                            botData.style === style.id
                              ? "ring-2 ring-primary bg-primary/5"
                              : ""
                          }`}
                          onClick={() => updateBotData({ style: style.id })}
                        >
                          <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                              <div>
                                <h4 className="font-medium">{style.label}</h4>
                                <p className="text-sm text-muted-foreground">
                                  {style.description}
                                </p>
                              </div>
                              {botData.style === style.id && (
                                <Check className="w-5 h-5 text-primary" />
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Step 4: Appearance */}
              {currentStep === 4 && (
                <div className="space-y-6">
                  <div className="space-y-3">
                    <Label>Màu chủ đạo</Label>
                    <div className="flex flex-wrap gap-3">
                      {colors.map((color) => (
                        <button
                          key={color}
                          className={`w-10 h-10 rounded-full border-2 transition-all ${
                            botData.primaryColor === color
                              ? "border-foreground scale-110"
                              : "border-border hover:scale-105"
                          }`}
                          style={{ backgroundColor: color }}
                          onClick={() => updateBotData({ primaryColor: color })}
                        />
                      ))}
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Label>Giao diện</Label>
                    <Select
                      value={botData.theme}
                      onValueChange={(value) =>
                        updateBotData({ theme: value as any })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="light">Sáng</SelectItem>
                        <SelectItem value="dark">Tối</SelectItem>
                        <SelectItem value="auto">Tự động</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-3">
                    <Label>Vị trí hiển thị</Label>
                    <div className="grid grid-cols-2 gap-3">
                      {positions.map((position) => (
                        <Card
                          key={position.id}
                          className={`cursor-pointer transition-all hover:shadow-md ${
                            botData.position === position.id
                              ? "ring-2 ring-primary bg-primary/5"
                              : ""
                          }`}
                          onClick={() =>
                            updateBotData({ position: position.id as any })
                          }
                        >
                          <CardContent className="p-4 text-center">
                            <div className="text-2xl mb-2">{position.icon}</div>
                            <div className="font-medium">{position.label}</div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Step 5: Preview */}
              {currentStep === 5 && (
                <div className="space-y-6">
                  <div className="text-center">
                    <div
                      className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center"
                      style={{ backgroundColor: botData.primaryColor }}
                    >
                      <Bot className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold">{botData.name}</h3>
                    <p className="text-muted-foreground">
                      {botData.description}
                    </p>
                  </div>

                  <Card className="bg-muted/30">
                    <CardContent className="p-4">
                      <h4 className="font-semibold mb-3">Thông tin ChatBot:</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Giới tính:</span>
                          <span className="capitalize">
                            {botData.gender === "male"
                              ? "Nam"
                              : botData.gender === "female"
                                ? "Nữ"
                                : "Trung tính"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Phong cách:</span>
                          <span>
                            {styles.find((s) => s.id === botData.style)?.label}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Giao diện:</span>
                          <span className="capitalize">
                            {botData.theme === "light"
                              ? "Sáng"
                              : botData.theme === "dark"
                                ? "Tối"
                                : "Tự động"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Vị trí:</span>
                          <span>
                            {
                              positions.find((p) => p.id === botData.position)
                                ?.label
                            }
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <div className="flex items-center space-x-2 text-green-800">
                      <Check className="w-5 h-5" />
                      <span className="font-medium">
                        ChatBot đã sẵn sàng tạo!
                      </span>
                    </div>
                    <p className="text-green-700 text-sm mt-1">
                      Sau khi tạo, bạn sẽ nhận được mã nhúng để tích hợp vào
                      website.
                    </p>
                  </div>
                </div>
              )}
            </CardContent>

            {/* Navigation */}
            <div className="flex justify-between p-6 border-t">
              <Button
                variant="outline"
                onClick={handlePrevious}
                disabled={currentStep === 1}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Quay lại
              </Button>

              {currentStep < totalSteps ? (
                <Button
                  onClick={handleNext}
                  disabled={!isStepValid()}
                  className="bg-gradient-to-r from-primary to-primary/80"
                >
                  Tiếp theo
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              ) : (
                <Button
                  onClick={handleSubmit}
                  className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
                >
                  <Check className="w-4 h-4 mr-2" />
                  Tạo ChatBot
                </Button>
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
