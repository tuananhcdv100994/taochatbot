import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Bot as BotIcon,
  Users,
  Crown,
  LogOut,
  Settings,
  MoreHorizontal,
  Trash2,
  UserCheck,
  UserX,
  Shield,
  MessageSquare,
  TrendingUp,
  Zap,
  Activity,
  Database,
  Cpu,
  User,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "@/lib/api";
import { User as UserType } from "@shared/api";

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState<UserType | null>(null);
  const [users, setUsers] = useState<UserType[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [userData, usersData] = await Promise.all([
        api.getCurrentUser(),
        api.getAllUsers(),
      ]);

      if (userData.role !== "admin") {
        navigate("/dashboard");
        return;
      }

      setUser(userData);
      setUsers(usersData);
    } catch (error) {
      console.error("Failed to load data:", error);
      localStorage.removeItem("auth_token");
      navigate("/login");
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await api.logout();
    } catch (error) {
      console.error("Logout error:", error);
    }
    navigate("/");
  };

  const handleUpgradeUser = async (userId: string) => {
    try {
      await api.updateUserPlan(userId, "pro");
      setUsers(users.map((u) => (u.id === userId ? { ...u, plan: "pro" } : u)));
    } catch (error) {
      alert("Không thể nâng cấp user");
    }
  };

  const handleDowngradeUser = async (userId: string) => {
    try {
      await api.updateUserPlan(userId, "free");
      setUsers(
        users.map((u) => (u.id === userId ? { ...u, plan: "free" } : u)),
      );
    } catch (error) {
      alert("Không thể hạ cấp user");
    }
  };

  const handleDeleteUser = async (userId: string) => {
    try {
      await api.deleteUser(userId);
      setUsers(users.filter((u) => u.id !== userId));
    } catch (error) {
      alert("Không thể xóa user");
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("vi-VN");
  };

  const totalUsers = users.length;
  const proUsers = users.filter((u) => u.plan === "pro").length;
  const freeUsers = users.filter((u) => u.plan === "free").length;
  const totalBots = users.reduce((sum, u) => sum + (u.botCount || 0), 0);
  const adminUsers = users.filter((u) => u.role === "admin").length;
  const totalMessages = users.reduce(
    (sum, u) => sum + (u.messageCount || 0),
    0,
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-background flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 neo-grid opacity-20"></div>
        <div className="text-center relative z-10">
          <div className="neo-glow w-16 h-16 border-2 border-cyan-500 border-t-purple-500 rounded-full animate-spin mx-auto mb-6"></div>
          <p className="text-foreground text-lg font-medium vietnamese-text">
            🔄 Đang tải dữ liệu admin...
          </p>
          <div className="flex items-center justify-center space-x-2 mt-4">
            <div className="neo-led neo-led-cyan"></div>
            <div className="neo-led neo-led-purple"></div>
            <div className="neo-led neo-led-pink"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background relative overflow-hidden">
      {/* NEO Grid Background */}
      <div className="absolute inset-0 neo-grid opacity-20"></div>

      {/* Floating NEO orbs */}
      <div
        className="absolute top-10 left-10 w-96 h-96 rounded-full"
        style={{
          background:
            "radial-gradient(circle, hsl(var(--neo-cyan)) 0%, transparent 70%)",
        }}
      ></div>
      <div
        className="absolute bottom-10 right-10 w-80 h-80 rounded-full"
        style={{
          background:
            "radial-gradient(circle, hsl(var(--neo-purple)) 0%, transparent 70%)",
        }}
      ></div>

      {/* NEO Navigation */}
      <nav className="border-b border-cyan-500/30 bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/5 via-transparent to-purple-500/5"></div>
        <div className="container mx-auto px-4 py-4 flex items-center justify-between relative z-10">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <BotIcon className="h-8 w-8 text-cyan-400" />
              <div className="absolute inset-0 neo-glow">
                <BotIcon className="h-8 w-8 text-cyan-400 opacity-50" />
              </div>
            </div>
            <span className="text-2xl font-bold neo-text neo-mono">
              ChatBot AI Admin
            </span>
            <Badge className="neo-button text-black border-0">
              <Shield className="w-3 h-3 mr-1" />
              <span className="font-semibold">ADMIN</span>
              <Zap className="w-3 h-3 ml-1 animate-pulse" />
            </Badge>
          </div>

          <div className="flex items-center space-x-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="relative h-10 w-10 rounded-full neo-glow"
                >
                  <Avatar className="h-10 w-10 border-2 border-purple-400">
                    <AvatarImage src="/avatars/admin.png" alt="Avatar" />
                    <AvatarFallback className="bg-gradient-to-r from-purple-600 to-blue-600 text-white font-bold">
                      AD
                    </AvatarFallback>
                  </Avatar>
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-pulse border-2 border-background"></div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                className="w-56 neo-card text-foreground"
                align="end"
                forceMount
              >
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <div className="flex items-center space-x-2">
                      <p className="text-sm font-medium leading-none text-foreground">
                        {user?.fullName}
                      </p>
                      <div className="neo-led neo-led-cyan w-1.5 h-1.5"></div>
                    </div>
                    <p className="text-xs leading-none text-purple-300">
                      {user?.email}
                    </p>
                    <Badge className="bg-purple-600/80 text-white text-xs w-fit">
                      <Crown className="w-3 h-3 mr-1" />
                      Super Admin
                    </Badge>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link to="/dashboard" className="vietnamese-text">
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Dashboard User</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={handleLogout}
                  className="vietnamese-text"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Đăng xuất</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="flex space-x-1">
              <div className="neo-led neo-led-cyan w-2 h-2"></div>
              <div className="neo-led neo-led-purple w-2 h-2"></div>
              <div className="neo-led neo-led-pink w-2 h-2"></div>
            </div>
            <h1 className="text-4xl font-bold neo-text vietnamese-text">
              🔐 Admin Dashboard
            </h1>
            <div className="flex space-x-1">
              <div className="neo-led neo-led-pink w-2 h-2"></div>
              <div className="neo-led neo-led-purple w-2 h-2"></div>
              <div className="neo-led neo-led-cyan w-2 h-2"></div>
            </div>
          </div>
          <p className="text-purple-300 text-lg vietnamese-text">
            🚀 Quản lý người dùng và hệ thống AI
          </p>
        </div>

        {/* Admin Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white border-0">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-sm vietnamese-text">
                    🔌 Hệ thống
                  </p>
                  <p className="text-xl font-bold">Hoạt động bình thường</p>
                </div>
                <Activity className="h-8 w-8 text-blue-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-green-600 to-teal-600 text-white border-0">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100 text-sm vietnamese-text">
                    📈 Hiệu suất
                  </p>
                  <p className="text-xl font-bold">99.9% Uptime</p>
                </div>
                <Cpu className="h-8 w-8 text-green-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-orange-600 to-red-600 text-white border-0">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-100 text-sm vietnamese-text">
                    📊 Tổng tin nhắn
                  </p>
                  <p className="text-xl font-bold">
                    {totalMessages.toLocaleString()}
                  </p>
                </div>
                <MessageSquare className="h-8 w-8 text-orange-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="neo-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-cyan-400 vietnamese-text">
                👥 Tổng người dùng
              </CardTitle>
              <Users className="h-4 w-4 text-cyan-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">
                {totalUsers}
              </div>
              <p className="text-xs text-purple-300 vietnamese-text">
                🆓 {freeUsers} free, 👑 {proUsers} pro, 🔑 {adminUsers} admin
              </p>
            </CardContent>
          </Card>

          <Card className="neo-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-yellow-400 vietnamese-text">
                👑 Pro Users
              </CardTitle>
              <Crown className="h-4 w-4 text-yellow-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">
                {proUsers}
              </div>
              <p className="text-xs text-purple-300 vietnamese-text">
                📊{" "}
                {totalUsers > 0 ? Math.round((proUsers / totalUsers) * 100) : 0}
                % của tổng số
              </p>
            </CardContent>
          </Card>

          <Card className="neo-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-green-400 vietnamese-text">
                🤖 Tổng ChatBot
              </CardTitle>
              <BotIcon className="h-4 w-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">
                {totalBots}
              </div>
              <p className="text-xs text-purple-300 vietnamese-text">
                📈 Trung bình{" "}
                {totalUsers > 0 ? (totalBots / totalUsers).toFixed(1) : 0}{" "}
                bot/user
              </p>
            </CardContent>
          </Card>

          <Card className="neo-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-pink-400 vietnamese-text">
                💰 Doanh thu
              </CardTitle>
              <TrendingUp className="h-4 w-4 text-pink-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">
                {(proUsers * 299).toLocaleString()}k
              </div>
              <p className="text-xs text-purple-300 vietnamese-text">
                💵 VNĐ/tháng
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Users Table */}
        <Card className="neo-card">
          <CardHeader>
            <CardTitle className="text-foreground vietnamese-text flex items-center space-x-2">
              <Database className="h-5 w-5 text-blue-400" />
              <span>📋 Danh sách người dùng</span>
            </CardTitle>
            <CardDescription className="text-purple-300 vietnamese-text">
              🔧 Quản lý tất cả người dùng trong hệ thống AI
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow className="border-purple-500/30">
                  <TableHead className="text-purple-300 vietnamese-text">
                    👤 Người dùng
                  </TableHead>
                  <TableHead className="text-purple-300 vietnamese-text">
                    📦 Gói
                  </TableHead>
                  <TableHead className="text-purple-300 vietnamese-text">
                    🤖 ChatBot
                  </TableHead>
                  <TableHead className="text-purple-300 vietnamese-text">
                    💬 Tin nhắn
                  </TableHead>
                  <TableHead className="text-purple-300 vietnamese-text">
                    📅 Ngày tạo
                  </TableHead>
                  <TableHead className="text-right text-purple-300 vietnamese-text">
                    ⚙️ Thao tác
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((u) => (
                  <TableRow
                    key={u.id}
                    className="border-purple-500/20 hover:bg-purple-900/20"
                  >
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <Avatar className="h-10 w-10 border-2 border-purple-400">
                          <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white font-bold">
                            {u.fullName
                              .split(" ")
                              .map((n) => n[0])
                              .join("")
                              .toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium text-foreground vietnamese-text">
                            {u.fullName}
                          </div>
                          <div className="text-sm text-purple-300">
                            {u.email}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={
                          u.plan === "pro"
                            ? "neo-button text-black border-0"
                            : "bg-background/50 border border-cyan-500/30 text-cyan-400"
                        }
                      >
                        {u.plan === "pro" ? (
                          <>
                            <Crown className="w-3 h-3 mr-1" />
                            👑 Pro
                          </>
                        ) : (
                          "🆓 Free"
                        )}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-foreground font-medium">
                      🤖 {u.botCount || 0}
                    </TableCell>
                    <TableCell className="text-foreground font-medium">
                      💬 {u.messageCount || 0}
                    </TableCell>
                    <TableCell className="text-purple-300 vietnamese-text">
                      📅 {u.createdAt ? formatDate(u.createdAt) : "-"}
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            className="h-8 w-8 p-0 text-purple-300 hover:text-foreground"
                          >
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent
                          className="neo-card text-foreground"
                          align="end"
                        >
                          {u.role === "admin" && (
                            <DropdownMenuItem
                              disabled
                              className="text-purple-300"
                            >
                              <Shield className="mr-2 h-4 w-4" />
                              🔒 Admin User (Protected)
                            </DropdownMenuItem>
                          )}
                          {u.role !== "admin" && (
                            <>
                              {u.plan === "free" ? (
                                <DropdownMenuItem
                                  onClick={() => handleUpgradeUser(u.id)}
                                  className="vietnamese-text"
                                >
                                  <UserCheck className="mr-2 h-4 w-4" />
                                  👑 Nâng cấp Pro
                                </DropdownMenuItem>
                              ) : (
                                <DropdownMenuItem
                                  onClick={() => handleDowngradeUser(u.id)}
                                  className="vietnamese-text"
                                >
                                  <UserX className="mr-2 h-4 w-4" />
                                  🆓 Hạ cấp Free
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuSeparator className="bg-purple-500/30" />
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <DropdownMenuItem
                                    className="text-red-400 vietnamese-text"
                                    onSelect={(e) => e.preventDefault()}
                                  >
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    🗑️ Xóa người dùng
                                  </DropdownMenuItem>
                                </AlertDialogTrigger>
                                <AlertDialogContent className="neo-card">
                                  <AlertDialogHeader>
                                    <AlertDialogTitle className="vietnamese-text text-foreground">
                                      ⚠️ Xác nhận xóa người dùng
                                    </AlertDialogTitle>
                                    <AlertDialogDescription className="vietnamese-text text-muted-foreground">
                                      🚨 Bạn có chắc chắn muốn xóa người dùng{" "}
                                      <strong>{u.fullName}</strong>?
                                      <br />
                                      <br />
                                      ⚠️ <strong>Cảnh báo:</strong> Hành động
                                      này không thể hoàn tác và sẽ:
                                      <ul className="list-disc list-inside mt-2 space-y-1">
                                        <li>
                                          Xóa vĩnh viễn tài khoản người dùng
                                        </li>
                                        <li>
                                          Xóa tất cả {u.botCount || 0} chatbot
                                          của người dùng
                                        </li>
                                        <li>Xóa tất cả dữ liệu liên quan</li>
                                      </ul>
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel className="vietnamese-text">
                                      ❌ Hủy bỏ
                                    </AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => handleDeleteUser(u.id)}
                                      className="bg-red-600 hover:bg-red-700 vietnamese-text"
                                    >
                                      🗑️ Xác nhận xóa
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
