import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Bot as BotIcon,
  ArrowLeft,
  Users,
  MessageCircle,
  Phone,
  Mail,
  Calendar,
  Eye,
} from "lucide-react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { api } from "@/lib/api";

interface Customer {
  sessionId: string;
  phoneNumber?: string;
  email?: string;
  name?: string;
  firstMessage: string;
  lastActive: string;
  messageCount: number;
  lastMessage?: string;
}

interface Conversation {
  sessionId: string;
  customer: {
    phoneNumber?: string;
    email?: string;
    name?: string;
    firstMessage: string;
    lastActive: string;
  };
  messages: Array<{
    message: string;
    response: string;
    timestamp: string;
  }>;
}

export default function CustomerManagement() {
  const navigate = useNavigate();
  const { botId } = useParams<{ botId: string }>();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selectedConversation, setSelectedConversation] =
    useState<Conversation | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadingConversation, setLoadingConversation] = useState(false);

  useEffect(() => {
    if (botId) {
      loadCustomers();
    }
  }, [botId]);

  const loadCustomers = async () => {
    try {
      const response = await fetch(`/api/chatbot/${botId}/customers`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("auth_token")}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setCustomers(data.customers || []);
      } else {
        console.error("Failed to load customers");
      }
    } catch (error) {
      console.error("Error loading customers:", error);
    } finally {
      setLoading(false);
    }
  };

  const loadConversation = async (sessionId: string) => {
    setLoadingConversation(true);
    try {
      const response = await fetch(`/api/chatbot/conversation/${sessionId}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("auth_token")}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setSelectedConversation(data);
      } else {
        console.error("Failed to load conversation");
      }
    } catch (error) {
      console.error("Error loading conversation:", error);
    } finally {
      setLoadingConversation(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString("vi-VN");
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString("vi-VN");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-accent/10 to-primary/5 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
          <p>Đang tải dữ liệu khách hàng...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-accent/10 to-primary/5">
      {/* Navigation */}
      <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/dashboard" className="flex items-center space-x-2">
            <BotIcon className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              ChatBot AI
            </span>
          </Link>

          <div className="flex items-center space-x-4">
            <Badge variant="outline">Quản lý khách hàng</Badge>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center mb-8">
          <Link to="/dashboard">
            <Button variant="ghost" size="sm" className="mr-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Dashboard
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold">Quản lý khách hàng</h1>
            <p className="text-muted-foreground">
              Theo dõi và quản lý khách hàng đã chat với bot
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Tổng khách hàng
              </CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{customers.length}</div>
              <p className="text-xs text-muted-foreground">
                Đã tương tác với bot
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Có số điện thoại
              </CardTitle>
              <Phone className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {customers.filter((c) => c.phoneNumber).length}
              </div>
              <p className="text-xs text-muted-foreground">
                {customers.length > 0
                  ? Math.round(
                      (customers.filter((c) => c.phoneNumber).length /
                        customers.length) *
                        100,
                    )
                  : 0}
                % khách hàng
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Tổng tin nhắn
              </CardTitle>
              <MessageCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {customers.reduce((sum, c) => sum + c.messageCount, 0)}
              </div>
              <p className="text-xs text-muted-foreground">
                Trung bình{" "}
                {customers.length > 0
                  ? Math.round(
                      customers.reduce((sum, c) => sum + c.messageCount, 0) /
                        customers.length,
                    )
                  : 0}{" "}
                tin nhắn/khách
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Customer List */}
        <Card>
          <CardHeader>
            <CardTitle>Danh sách khách hàng</CardTitle>
            <CardDescription>
              Khách hàng đã tương tác với chatbot của bạn
            </CardDescription>
          </CardHeader>
          <CardContent>
            {customers.length === 0 ? (
              <div className="text-center py-8">
                <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-semibold mb-2">
                  Chưa có khách hàng nào
                </h3>
                <p className="text-muted-foreground">
                  Khách hàng sẽ xuất hiện ở đây khi họ chat với bot của bạn
                </p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Khách hàng</TableHead>
                    <TableHead>Liên hệ</TableHead>
                    <TableHead>Tin nhắn đầu</TableHead>
                    <TableHead>Số tin nhắn</TableHead>
                    <TableHead>Hoạt động cuối</TableHead>
                    <TableHead className="text-right">Thao tác</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {customers.map((customer) => (
                    <TableRow key={customer.sessionId}>
                      <TableCell>
                        <div className="font-medium">
                          {customer.name || "Khách hàng"}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          ID: {customer.sessionId.slice(0, 8)}...
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          {customer.phoneNumber && (
                            <div className="flex items-center text-sm">
                              <Phone className="w-3 h-3 mr-1" />
                              {customer.phoneNumber}
                            </div>
                          )}
                          {customer.email && (
                            <div className="flex items-center text-sm">
                              <Mail className="w-3 h-3 mr-1" />
                              {customer.email}
                            </div>
                          )}
                          {!customer.phoneNumber && !customer.email && (
                            <Badge variant="outline" className="text-xs">
                              Chưa có thông tin
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="max-w-[200px] truncate">
                          {customer.firstMessage}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">
                          {customer.messageCount}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center text-sm">
                          <Calendar className="w-3 h-3 mr-1" />
                          {formatDate(customer.lastActive)}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() =>
                                loadConversation(customer.sessionId)
                              }
                            >
                              <Eye className="w-4 h-4 mr-2" />
                              Xem chi tiết
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-4xl max-h-[80vh]">
                            <DialogHeader>
                              <DialogTitle>Chi tiết cuộc hội thoại</DialogTitle>
                              <DialogDescription>
                                Lịch sử chat với khách hàng
                              </DialogDescription>
                            </DialogHeader>

                            {loadingConversation ? (
                              <div className="flex items-center justify-center py-8">
                                <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin"></div>
                                <span className="ml-2">Đang tải...</span>
                              </div>
                            ) : selectedConversation ? (
                              <div className="space-y-4">
                                {/* Customer Info */}
                                <div className="bg-muted/50 p-4 rounded-lg">
                                  <h4 className="font-semibold mb-2">
                                    Thông tin khách hàng
                                  </h4>
                                  <div className="grid grid-cols-2 gap-4 text-sm">
                                    <div>
                                      <span className="text-muted-foreground">
                                        ID Session:
                                      </span>
                                      <div className="font-mono">
                                        {selectedConversation.sessionId}
                                      </div>
                                    </div>
                                    {selectedConversation.customer
                                      .phoneNumber && (
                                      <div>
                                        <span className="text-muted-foreground">
                                          Số điện thoại:
                                        </span>
                                        <div className="font-medium">
                                          {
                                            selectedConversation.customer
                                              .phoneNumber
                                          }
                                        </div>
                                      </div>
                                    )}
                                    {selectedConversation.customer.email && (
                                      <div>
                                        <span className="text-muted-foreground">
                                          Email:
                                        </span>
                                        <div className="font-medium">
                                          {selectedConversation.customer.email}
                                        </div>
                                      </div>
                                    )}
                                    <div>
                                      <span className="text-muted-foreground">
                                        Hoạt động cu���i:
                                      </span>
                                      <div className="font-medium">
                                        {formatDate(
                                          selectedConversation.customer
                                            .lastActive,
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                </div>

                                {/* Conversation */}
                                <div>
                                  <h4 className="font-semibold mb-3">
                                    Lịch sử hội thoại
                                  </h4>
                                  <ScrollArea className="h-[400px] border rounded-lg p-4">
                                    <div className="space-y-4">
                                      {selectedConversation.messages.map(
                                        (msg, index) => (
                                          <div
                                            key={index}
                                            className="space-y-2"
                                          >
                                            {/* User message */}
                                            <div className="flex justify-end">
                                              <div className="bg-primary text-primary-foreground rounded-lg px-4 py-2 max-w-[70%]">
                                                <p className="text-sm">
                                                  {msg.message}
                                                </p>
                                                <p className="text-xs opacity-70 mt-1">
                                                  {formatTime(msg.timestamp)}
                                                </p>
                                              </div>
                                            </div>

                                            {/* Bot response */}
                                            <div className="flex justify-start">
                                              <div className="bg-muted rounded-lg px-4 py-2 max-w-[70%]">
                                                <p className="text-sm">
                                                  {msg.response}
                                                </p>
                                                <p className="text-xs text-muted-foreground mt-1">
                                                  ChatBot AI
                                                </p>
                                              </div>
                                            </div>
                                          </div>
                                        ),
                                      )}
                                    </div>
                                  </ScrollArea>
                                </div>
                              </div>
                            ) : (
                              <div className="text-center py-4">
                                Không thể tải cuộc hội thoại
                              </div>
                            )}
                          </DialogContent>
                        </Dialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
