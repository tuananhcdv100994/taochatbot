import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Crown, Phone, Send, Check } from "lucide-react";

interface UpgradeModalProps {
  children: React.ReactNode;
}

export default function UpgradeModal({ children }: UpgradeModalProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    fullName: "",
    phone: "",
    email: "",
    company: "",
    plan: "pro",
    message: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    // Simulate submission
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);

      // Auto close after 3 seconds
      setTimeout(() => {
        setIsOpen(false);
        setSubmitted(false);
        setFormData({
          fullName: "",
          phone: "",
          email: "",
          company: "",
          plan: "pro",
          message: "",
        });
      }, 3000);
    }, 1500);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleCallHotline = () => {
    window.open("tel:0792762794", "_self");
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Crown className="w-5 h-5 mr-2 text-primary" />
            Nâng cấp lên Pro
          </DialogTitle>
          <DialogDescription>
            Điền thông tin bên dưới để được tư vấn nâng cấp gói Pro
          </DialogDescription>
        </DialogHeader>

        {submitted ? (
          <div className="py-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Đã gửi yêu cầu!</h3>
            <p className="text-muted-foreground">
              Chúng tôi sẽ liên hệ với bạn trong vòng 24h để tư vấn gói Pro.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fullName">Họ và tên *</Label>
                <Input
                  id="fullName"
                  placeholder="Nguyễn Văn A"
                  value={formData.fullName}
                  onChange={(e) =>
                    handleInputChange("fullName", e.target.value)
                  }
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Số điện thoại *</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="0901234567"
                  value={formData.phone}
                  onChange={(e) => handleInputChange("phone", e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                placeholder="name@company.com"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="company">Công ty/Tổ chức</Label>
              <Input
                id="company"
                placeholder="Tên công ty (nếu có)"
                value={formData.company}
                onChange={(e) => handleInputChange("company", e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="plan">Gói quan tâm</Label>
              <Select
                value={formData.plan}
                onValueChange={(value) => handleInputChange("plan", value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pro">Pro - 299k/tháng</SelectItem>
                  <SelectItem value="business">Business - Liên hệ</SelectItem>
                  <SelectItem value="enterprise">
                    Enterprise - Liên hệ
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="message">Ghi chú</Label>
              <Textarea
                id="message"
                placeholder="Mô tả nhu cầu sử dụng của bạn..."
                value={formData.message}
                onChange={(e) => handleInputChange("message", e.target.value)}
                rows={3}
              />
            </div>

            <Alert>
              <Phone className="h-4 w-4" />
              <AlertDescription>
                Bạn cũng có thể gọi trực tiếp hotline:{" "}
                <strong>0792762794</strong> để được tư vấn ngay
              </AlertDescription>
            </Alert>

            <DialogFooter className="flex-col sm:flex-row gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={handleCallHotline}
                className="w-full sm:w-auto"
              >
                <Phone className="w-4 h-4 mr-2" />
                Gọi ngay: 0792762794
              </Button>
              <Button
                type="submit"
                disabled={
                  submitting ||
                  !formData.fullName ||
                  !formData.phone ||
                  !formData.email
                }
                className="w-full sm:w-auto bg-gradient-to-r from-primary to-primary/80"
              >
                {submitting ? (
                  <div className="flex items-center">
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                    Đang gửi...
                  </div>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Gửi yêu cầu
                  </>
                )}
              </Button>
            </DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
