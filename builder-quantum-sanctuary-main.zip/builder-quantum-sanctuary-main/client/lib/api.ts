import { User, Bot, AuthResponse, ApiResponse } from "@shared/api";

const API_BASE = "/api";

class ApiService {
  private getAuthHeader() {
    const token = localStorage.getItem("auth_token");
    return token ? { Authorization: `Bearer ${token}` } : {};
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {},
  ): Promise<T> {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      headers: {
        "Content-Type": "application/json",
        ...this.getAuthHeader(),
        ...options.headers,
      },
      ...options,
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || "Có lỗi xảy ra");
    }

    return response.json();
  }

  // Authentication
  async register(data: {
    email: string;
    password: string;
    fullName: string;
    phoneNumber: string;
  }): Promise<AuthResponse> {
    return this.request("/auth/register", {
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  async login(data: {
    email: string;
    password: string;
  }): Promise<AuthResponse> {
    return this.request("/auth/login", {
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  async logout(): Promise<void> {
    await this.request("/auth/logout", { method: "POST" });
    localStorage.removeItem("auth_token");
  }

  async getCurrentUser(): Promise<User> {
    return this.request("/auth/user");
  }

  // Bot management
  async getBots(): Promise<Bot[]> {
    return this.request("/bots");
  }

  async createBot(
    botData: Partial<Bot>,
  ): Promise<{ success: boolean; bot: Bot }> {
    return this.request("/bots", {
      method: "POST",
      body: JSON.stringify(botData),
    });
  }

  async updateBot(
    id: string,
    botData: Partial<Bot>,
  ): Promise<{ success: boolean; bot: Bot }> {
    return this.request(`/bots/${id}`, {
      method: "PUT",
      body: JSON.stringify(botData),
    });
  }

  async deleteBot(id: string): Promise<{ success: boolean }> {
    return this.request(`/bots/${id}`, {
      method: "DELETE",
    });
  }

  async getBotEmbedCode(id: string): Promise<{ embedCode: string }> {
    return this.request(`/bots/${id}/embed`);
  }

  // Admin functions
  async getAllUsers(): Promise<User[]> {
    return this.request("/admin/users");
  }

  async updateUserPlan(
    userId: string,
    plan: "free" | "pro",
  ): Promise<{ success: boolean }> {
    return this.request(`/admin/users/${userId}/plan`, {
      method: "PUT",
      body: JSON.stringify({ plan }),
    });
  }

  async deleteUser(userId: string): Promise<{ success: boolean }> {
    return this.request(`/admin/users/${userId}`, {
      method: "DELETE",
    });
  }

  // Chatbot testing
  async testChatbot(data: {
    message: string;
    botId: string;
    knowledge: string;
    apiKey: string;
  }): Promise<{
    success: boolean;
    response?: string;
    error?: string;
    timestamp?: string;
  }> {
    return this.request("/chatbot/test", {
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  async checkEmbedStatus(data: {
    websiteUrl: string;
    botId: string;
    apiKey: string;
  }): Promise<{
    success: boolean;
    status: "active" | "warning" | "inactive";
    message: string;
    websiteUrl: string;
    lastChecked: string;
  }> {
    return this.request("/chatbot/check-embed", {
      method: "POST",
      body: JSON.stringify(data),
    });
  }
}

export const api = new ApiService();
