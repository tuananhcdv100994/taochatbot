/**
 * Shared code between client and server
 * Useful to share types between client and server
 * and/or small pure JS functions that can be used on both client and server
 */

/**
 * Example response type for /api/demo
 */
export interface DemoResponse {
  message: string;
}

export interface User {
  id: string;
  email: string;
  fullName: string;
  phoneNumber: string;
  role: "user" | "admin";
  plan: "free" | "pro";
  botCount: number;
  messageCount: number;
  createdAt?: string;
}

export interface Bot {
  id: string;
  userId: string;
  name: string;
  description: string;
  knowledge: string;
  gender: "male" | "female" | "neutral";
  style: string;
  primaryColor: string;
  theme: "light" | "dark" | "auto";
  position: "bottom-right" | "bottom-left" | "top-right" | "top-left";
  status: "active" | "inactive";
  createdAt: string;
  messageCount: number;
  apiKey?: string;
  websiteUrl?: string;
}

export interface AuthResponse {
  success: boolean;
  token?: string;
  user?: User;
  error?: string;
}

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
}
