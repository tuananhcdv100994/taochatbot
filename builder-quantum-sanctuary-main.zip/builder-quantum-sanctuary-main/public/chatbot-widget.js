(function () {
  "use strict";

  // Prevent multiple instances
  if (window.ChatBotWidgetLoaded) {
    console.warn("ChatBot Widget already loaded");
    return;
  }
  window.ChatBotWidgetLoaded = true;

  // Default configuration
  let config = {
    botId: "default",
    botName: "ChatBot AI",
    primaryColor: "#8b5cf6",
    theme: "light",
    apiKey: "demo",
    position: "bottom-right",
    serverUrl: "http://localhost:8080",
  };

  let isOpen = false;
  let sessionId = null;
  let messageCount = 0;
  let widget = null;

  // Parse configuration from script attributes
  function parseConfig() {
    const scripts = document.getElementsByTagName("script");
    for (let script of scripts) {
      if (script.src && script.src.includes("chatbot-widget.js")) {
        const botId = script.getAttribute("data-bot-id");
        const botName = script.getAttribute("data-bot-name");
        const primaryColor = script.getAttribute("data-primary-color");
        const theme = script.getAttribute("data-theme");
        const apiKey = script.getAttribute("data-api-key");
        const position = script.getAttribute("data-position");
        const serverUrl = script.getAttribute("data-server-url");

        if (botId) config.botId = botId;
        if (botName) config.botName = botName;
        if (primaryColor) config.primaryColor = primaryColor;
        if (theme) config.theme = theme;
        if (apiKey) config.apiKey = apiKey;
        if (position) config.position = position;
        if (serverUrl) config.serverUrl = serverUrl;
        break;
      }
    }
  }

  // Create widget HTML
  function createWidget() {
    const widgetHTML = `
      <div id="chatbot-widget-container" style="position: fixed; z-index: 999999; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
        <!-- Chat Toggle Button -->
        <button id="chatbot-toggle" style="
          width: 60px;
          height: 60px;
          border-radius: 50%;
          border: none;
          cursor: pointer;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.3s ease;
          background: ${config.primaryColor};
        ">
          <svg width="28" height="28" fill="white" viewBox="0 0 24 24">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
        </button>

        <!-- Chat Window -->
        <div id="chatbot-window" style="
          width: 350px;
          height: 500px;
          background: white;
          border-radius: 12px;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
          display: none;
          flex-direction: column;
          overflow: hidden;
        ">
          <div id="chatbot-header" style="
            padding: 16px;
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: ${config.primaryColor};
          ">
            <div style="display: flex; align-items: center;">
              <div style="
                width: 32px;
                height: 32px;
                background: rgba(255, 255, 255, 0.2);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-right: 12px;
              ">
                <svg width="18" height="18" fill="white" viewBox="0 0 24 24">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                </svg>
              </div>
              <div>
                <div style="font-weight: 600; font-size: 14px;">${config.botName}</div>
                <div style="font-size: 12px; opacity: 0.9;">Trực tuyến</div>
              </div>
            </div>
            <button id="chatbot-close" style="
              background: none;
              border: none;
              color: white;
              cursor: pointer;
              padding: 4px;
              border-radius: 4px;
              font-size: 18px;
            ">×</button>
          </div>

          <div id="chatbot-messages" style="
            flex: 1;
            padding: 16px;
            overflow-y: auto;
            background: #f8fafc;
          ">
            <!-- Messages will be added here -->
          </div>

          <div id="chatbot-input" style="
            padding: 16px;
            background: white;
            border-top: 1px solid #e2e8f0;
            display: flex;
            gap: 8px;
          ">
            <input type="text" id="chatbot-message-input" placeholder="Nhập tin nhắn..." style="
              flex: 1;
              padding: 12px;
              border: 1px solid #e2e8f0;
              border-radius: 8px;
              font-size: 14px;
              outline: none;
              font-family: inherit;
            "/>
            <button id="chatbot-send" style="
              padding: 12px;
              border: none;
              border-radius: 8px;
              cursor: pointer;
              width: 44px;
              height: 44px;
              display: flex;
              align-items: center;
              justify-content: center;
              background: ${config.primaryColor};
              color: white;
            ">
              <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24">
                <path d="M2 21l21-9L2 3v7l15 2-15 2v7z"/>
              </svg>
            </button>
          </div>
        </div>
      </div>
    `;

    // Create container
    const container = document.createElement("div");
    container.innerHTML = widgetHTML;
    widget = container.firstElementChild;

    // Apply position
    applyPosition();

    document.body.appendChild(widget);

    // Add event listeners
    document
      .getElementById("chatbot-toggle")
      .addEventListener("click", function (e) {
        e.preventDefault();
        toggleChat();
      });
    document
      .getElementById("chatbot-close")
      .addEventListener("click", function (e) {
        e.preventDefault();
        toggleChat();
      });
    document
      .getElementById("chatbot-send")
      .addEventListener("click", function (e) {
        e.preventDefault();
        sendMessage();
      });
    document
      .getElementById("chatbot-message-input")
      .addEventListener("keypress", function (e) {
        if (e.key === "Enter") {
          e.preventDefault();
          sendMessage();
        }
      });

    // Add hover effect to toggle button
    const toggle = document.getElementById("chatbot-toggle");
    toggle.addEventListener("mouseenter", function () {
      this.style.transform = "scale(1.1)";
    });
    toggle.addEventListener("mouseleave", function () {
      this.style.transform = "scale(1)";
    });

    // Add initial message
    setTimeout(() => {
      addMessage(
        `Xin chào! Tôi là ${config.botName}. Tôi có thể giúp gì cho bạn?`,
      );
    }, 500);
  }

  // Apply position styles
  function applyPosition() {
    if (!widget) return;

    const toggle = document.getElementById("chatbot-toggle");
    const window = document.getElementById("chatbot-window");

    // Reset positions
    ["top", "bottom", "left", "right"].forEach((pos) => {
      toggle.style[pos] = "auto";
      window.style[pos] = "auto";
    });

    switch (config.position) {
      case "bottom-left":
        toggle.style.bottom = "20px";
        toggle.style.left = "20px";
        window.style.bottom = "90px";
        window.style.left = "20px";
        widget.style.bottom = "0";
        widget.style.left = "0";
        break;
      case "top-right":
        toggle.style.top = "20px";
        toggle.style.right = "20px";
        window.style.top = "90px";
        window.style.right = "20px";
        widget.style.top = "0";
        widget.style.right = "0";
        break;
      case "top-left":
        toggle.style.top = "20px";
        toggle.style.left = "20px";
        window.style.top = "90px";
        window.style.left = "20px";
        widget.style.top = "0";
        widget.style.left = "0";
        break;
      default: // bottom-right
        toggle.style.bottom = "20px";
        toggle.style.right = "20px";
        window.style.bottom = "90px";
        window.style.right = "20px";
        widget.style.bottom = "0";
        widget.style.right = "0";
    }

    // Mobile responsive
    if (window.innerWidth < 400) {
      window.style.width = "calc(100vw - 40px)";
      window.style.right = "20px";
      window.style.left = "20px";
    }
  }

  // Toggle chat window
  function toggleChat() {
    const window = document.getElementById("chatbot-window");
    if (isOpen) {
      window.style.display = "none";
      isOpen = false;
    } else {
      window.style.display = "flex";
      isOpen = true;
      document.getElementById("chatbot-message-input").focus();
    }
  }

  // Add message to chat
  function addMessage(content, isUser = false) {
    const messagesContainer = document.getElementById("chatbot-messages");
    const messageDiv = document.createElement("div");
    messageDiv.style.cssText = `
      margin-bottom: 16px;
      display: flex;
      align-items: flex-start;
      ${isUser ? "justify-content: flex-end;" : ""}
    `;

    if (isUser) {
      messageDiv.innerHTML = `
        <div style="
          padding: 12px;
          border-radius: 8px;
          font-size: 14px;
          line-height: 1.5;
          max-width: 250px;
          word-wrap: break-word;
          background: ${config.primaryColor};
          color: white;
          border-bottom-right-radius: 4px;
        ">${escapeHtml(content)}</div>
      `;
    } else {
      messageDiv.innerHTML = `
        <div style="
          width: 32px;
          height: 32px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-right: 8px;
          flex-shrink: 0;
          background: ${config.primaryColor};
        ">
          <svg width="16" height="16" fill="white" viewBox="0 0 24 24">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
        </div>
        <div style="
          padding: 12px;
          border-radius: 8px;
          font-size: 14px;
          line-height: 1.5;
          max-width: 250px;
          word-wrap: break-word;
          background: white;
          border-bottom-left-radius: 4px;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        ">${escapeHtml(content)}</div>
      `;
    }

    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  // Add typing indicator
  function addTypingIndicator() {
    const messagesContainer = document.getElementById("chatbot-messages");
    const typingDiv = document.createElement("div");
    typingDiv.id = "chatbot-typing-indicator";
    typingDiv.style.cssText = `
      margin-bottom: 16px;
      display: flex;
      align-items: flex-start;
    `;
    typingDiv.innerHTML = `
      <div style="
        width: 32px;
        height: 32px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 8px;
        flex-shrink: 0;
        background: ${config.primaryColor};
      ">
        <svg width="16" height="16" fill="white" viewBox="0 0 24 24">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
        </svg>
      </div>
      <div style="
        padding: 12px;
        border-radius: 8px;
        background: white;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      ">
        <div style="display: flex; gap: 4px; align-items: center;">
          <div class="typing-dot" style="
            width: 8px;
            height: 8px;
            background: #ccc;
            border-radius: 50%;
            animation: typing 1.4s infinite;
          "></div>
          <div class="typing-dot" style="
            width: 8px;
            height: 8px;
            background: #ccc;
            border-radius: 50%;
            animation: typing 1.4s infinite 0.2s;
          "></div>
          <div class="typing-dot" style="
            width: 8px;
            height: 8px;
            background: #ccc;
            border-radius: 50%;
            animation: typing 1.4s infinite 0.4s;
          "></div>
        </div>
      </div>
    `;

    // Add typing animation CSS
    if (!document.getElementById("chatbot-typing-styles")) {
      const style = document.createElement("style");
      style.id = "chatbot-typing-styles";
      style.textContent = `
        @keyframes typing {
          0%, 60%, 100% {
            transform: translateY(0);
            opacity: 0.4;
          }
          30% {
            transform: translateY(-10px);
            opacity: 1;
          }
        }
      `;
      document.head.appendChild(style);
    }

    messagesContainer.appendChild(typingDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  // Remove typing indicator
  function removeTypingIndicator() {
    const typing = document.getElementById("chatbot-typing-indicator");
    if (typing) typing.remove();
  }

  // Send message
  async function sendMessage() {
    console.log("SendMessage called (widget)");
    const input = document.getElementById("chatbot-message-input");
    if (!input) {
      console.error("Input element not found (widget)");
      return;
    }

    const message = input.value.trim();
    console.log("Message (widget):", message);

    if (!message) {
      console.log("Empty message, returning (widget)");
      return;
    }

    addMessage(message, true);
    input.value = "";
    messageCount++;

    addTypingIndicator();

    try {
      const response = await fetch(`${config.serverUrl}/api/chatbot/test`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message,
          botId: config.botId,
          botName: config.botName,
          knowledge: "Widget knowledge base",
          sessionId: sessionId,
        }),
      });

      const data = await response.json();
      removeTypingIndicator();

      if (data.success) {
        addMessage(data.response);
        if (data.sessionId) {
          sessionId = data.sessionId;
        }
      } else {
        addMessage(
          "Xin lỗi, có lỗi xảy ra: " + (data.error || "Unknown error"),
        );
      }
    } catch (error) {
      console.error("Send message error (widget):", error);
      removeTypingIndicator();
      addMessage("Không thể kết nối đến server. Vui lòng thử lại sau.");
    }
  }

  // Escape HTML
  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }

  // Handle window resize
  function handleResize() {
    applyPosition();
  }

  // Initialize widget
  function initWidget() {
    parseConfig();
    createWidget();

    // Add resize listener
    window.addEventListener("resize", handleResize);

    console.log("ChatBot Widget initialized:", config);
  }

  // Start when DOM is ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initWidget);
  } else {
    initWidget();
  }

  // Public API
  window.ChatBotWidget = {
    open: function () {
      if (!isOpen) toggleChat();
    },
    close: function () {
      if (isOpen) toggleChat();
    },
    toggle: toggleChat,
    config: config,
  };
})();
