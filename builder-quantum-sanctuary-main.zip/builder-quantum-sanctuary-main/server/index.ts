import express from "express";
import cors from "cors";
import path from "path";
import { handleDemo } from "./routes/demo";
import {
  handleRegister,
  handleLogin,
  handleGetUser,
  handleGetUserBots,
  handleCreateBot,
  handleDeleteBot,
  handleUpdateBot,
  handleGetBotEmbed,
  handleGetAllUsers,
  handleUpdateUserPlan,
  handleDeleteUser,
  handleLogout,
} from "./routes/users";
import {
  handleTestChatbot,
  handleCheckEmbedStatus,
  handleGetCustomers,
  handleGetConversation,
} from "./routes/chatbot";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Serve chatbot widget with specific path to avoid Vite conflicts
  app.get("/widget/chatbot.js", (_req, res) => {
    res.setHeader("Content-Type", "application/javascript");
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Cache-Control", "no-cache");
    res.sendFile(path.join(process.cwd(), "public", "chatbot-widget.js"));
  });

  // Debug endpoint
  app.get("/widget/status", (_req, res) => {
    res.json({
      status: "ok",
      widgetPath: "/widget/chatbot.js",
      timestamp: new Date().toISOString(),
      message: "ChatBot widget server is running",
    });
  });

  // Serve static files from public directory for other files
  app.use("/public", express.static(path.join(process.cwd(), "public")));

  // Serve test pages
  app.get("/test-widget", (_req, res) => {
    res.setHeader("Content-Type", "text/html");
    res.sendFile(path.join(process.cwd(), "public", "test-widget.html"));
  });

  app.get("/simple-test", (_req, res) => {
    res.setHeader("Content-Type", "text/html");
    res.sendFile(path.join(process.cwd(), "public", "simple-test.html"));
  });

  app.get("/minimal-test", (_req, res) => {
    res.setHeader("Content-Type", "text/html");
    res.sendFile(path.join(process.cwd(), "public", "minimal-test.html"));
  });

  app.get("/inline-test", (_req, res) => {
    res.setHeader("Content-Type", "text/html");
    res.sendFile(path.join(process.cwd(), "public", "inline-test.html"));
  });

  app.get("/iframe-widget", (_req, res) => {
    res.setHeader("Content-Type", "text/html");
    res.setHeader("X-Frame-Options", "ALLOWALL");
    res.setHeader("Content-Security-Policy", "frame-ancestors *");
    res.sendFile(path.join(process.cwd(), "public", "iframe-widget.html"));
  });

  app.get("/iframe-test", (_req, res) => {
    res.setHeader("Content-Type", "text/html");
    res.sendFile(path.join(process.cwd(), "public", "iframe-test.html"));
  });

  app.get("/test-iframe-simple", (_req, res) => {
    res.setHeader("Content-Type", "text/html");
    res.sendFile(path.join(process.cwd(), "public", "test-iframe-simple.html"));
  });

  app.get("/widget-test", (_req, res) => {
    res.setHeader("Content-Type", "text/html");
    res.sendFile(path.join(process.cwd(), "public", "widget-test.html"));
  });

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    res.json({ message: "Hello from Express server v2!" });
  });

  app.get("/api/demo", handleDemo);

  // Authentication routes
  app.post("/api/auth/register", handleRegister);
  app.post("/api/auth/login", handleLogin);
  app.post("/api/auth/logout", handleLogout);
  app.get("/api/auth/user", handleGetUser);

  // Bot management routes
  app.get("/api/bots", handleGetUserBots);
  app.post("/api/bots", handleCreateBot);
  app.put("/api/bots/:id", handleUpdateBot);
  app.delete("/api/bots/:id", handleDeleteBot);
  app.get("/api/bots/:id/embed", handleGetBotEmbed);

  // Admin routes
  app.get("/api/admin/users", handleGetAllUsers);
  app.put("/api/admin/users/:id/plan", handleUpdateUserPlan);
  app.delete("/api/admin/users/:id", handleDeleteUser);

  // Chatbot testing routes
  app.post("/api/chatbot/test", handleTestChatbot);
  app.post("/api/chatbot/check-embed", handleCheckEmbedStatus);

  // Customer management routes
  app.get("/api/chatbot/:botId/customers", handleGetCustomers);
  app.get("/api/chatbot/conversation/:sessionId", handleGetConversation);

  return app;
}
