import { RequestHandler } from "express";

// Google Gemini API configuration
const GEMINI_CONFIG = {
  url: "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent",
  apiKey: "AIzaSyANaiLoWgBxrDFJb6-5VLO4ve9ci3RHrcY",
};

// Call Google Gemini API
const callGeminiAPI = async (
  message: string,
  systemPrompt: string = "",
  chatHistory: Array<{ message: string; response: string }> = [],
) => {
  try {
    // Build conversation context for Gemini
    let contextText = systemPrompt;
    if (chatHistory.length > 0) {
      contextText += "\n\nLịch sử hội thoại:\n";
      chatHistory.slice(-3).forEach((h, i) => {
        contextText += `User: ${h.message}\nAssistant: ${h.response}\n`;
      });
    }
    contextText += `\n\nUser hiện tại: ${message}`;

    const response = await fetch(
      `${GEMINI_CONFIG.url}?key=${GEMINI_CONFIG.apiKey}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: contextText,
                },
              ],
            },
          ],
          generationConfig: {
            temperature: 0.8,
            topK: 40,
            topP: 0.9,
            maxOutputTokens: 500,
          },
        }),
      },
    );

    if (!response.ok) {
      throw new Error(`Gemini API error: ${response.status}`);
    }

    const data = await response.json();
    const generatedText = data.candidates?.[0]?.content?.parts?.[0]?.text;

    if (generatedText) {
      return generatedText.trim();
    }

    return "Xin lỗi, t��i không thể xử lý yêu cầu này lúc này.";
  } catch (error) {
    console.error("Gemini API error:", error);
    return null;
  }
};

// Enhanced AI response system with Google Gemini integration
const generateSmartResponse = async (
  message: string,
  knowledge: string,
  botName: string,
  chatHistory: Array<{ message: string; response: string }> = [],
  userInfo: { phoneNumber?: string; email?: string; name?: string } = {},
) => {
  const lowerMessage = message.toLowerCase();
  const lowerKnowledge = knowledge.toLowerCase();
  const messageCount = chatHistory.length;

  // Enhanced system prompt for better Vietnamese responses with Gemini
  const systemPrompt = `Bạn là ${botName}, một trợ lý AI thông minh và thân thiện được hỗ trợ bởi Google Gemini.
Kiến thức chuyên môn: ${knowledge}
Quy tắc trả lời:
- Bắt buộc trả lời bằng tiếng Việt tự nhiên, thân thiện
- Câu trả lời ngắn gọn nhưng đầy đủ thông tin (1-3 câu)
- Sử dụng emoji phù hợp để tạo sự gần gũi (👋 😊 💬 ✨ 👍)
- Nếu không chắc chắn, hãy hỏi thêm thông tin một cách lịch sự
- Khuyến khích khách hàng chia sẻ thông tin liên hệ khi phù hợp
- Tích cực, nhiệt tình, chuyên nghiệp và lu��n sẵn sàng hỗ trợ
- Không được trả lời bằng tiếng Anh trừ khi được yêu cầu cụ thể`;

  // Try to get AI response first for more natural conversation
  if (
    messageCount > 0 ||
    (!lowerMessage.includes("xin chào") &&
      !lowerMessage.includes("hello") &&
      !lowerMessage.includes("hi"))
  ) {
    const conversationHistory = [
      ...chatHistory
        .slice(-3)
        .map((h) => [
          { role: "user", content: h.message },
          { role: "assistant", content: h.response },
        ])
        .flat(),
      { role: "user", content: message },
    ];

    const aiResponse = await callGeminiAPI(message, systemPrompt, chatHistory);
    if (aiResponse) {
      // Post-process AI response to make it more suitable for Vietnamese chat
      let processedResponse = aiResponse.trim();

      // Add phone number request hint randomly after 2-3 messages
      if (messageCount >= 2 && Math.random() > 0.7 && !userInfo.phoneNumber) {
        processedResponse +=
          " \n\n💬 Nếu bạn muốn được tư vấn chi tiết hơn, có thể chia sẻ số điện thoại để tôi kết nối với chuyên viên hỗ trợ bạn nhé!";
      }

      return processedResponse;
    }
  }

  // Enhanced greeting responses
  if (
    lowerMessage.includes("xin chào") ||
    lowerMessage.includes("hello") ||
    lowerMessage.includes("hi") ||
    lowerMessage.includes("chào") ||
    messageCount === 0
  ) {
    const greetings = [
      `👋 Xin chào! Tôi là ${botName}, trợ lý AI thông minh của bạn. Hôm nay tôi có thể hỗ trợ gì cho bạn?`,
      `🌟 Chào bạn! Tôi là ${botName} - luôn sẵn sàng tư vấn và hỗ trợ. Bạn muốn tìm hiểu về điều gì nhé?`,
      `✨ Hello! Tôi là ${botName}, rất vui được gặp bạn! Hãy chia sẻ câu hỏi để tôi có thể giúp đỡ tốt nhất.`,
      `🤖 Chào mừng bạn đến với ${botName}! Tôi ở đây để hỗ trợ mọi thắc mắc của bạn. Cần tư vấn gì không?`,
    ];
    return greetings[Math.floor(Math.random() * greetings.length)];
  }

  // Phone number request (after 2-3 messages) - Enhanced
  if (messageCount >= 2 && Math.random() > 0.7 && !userInfo.phoneNumber) {
    const phoneRequests = [
      `💝 Để tôi có thể hỗ trợ bạn tốt nhất, bạn có thể chia sẻ số điện thoại để chuyên viên tư vấn trực tiếp không? Hoặc tiếp tục chat với tôi cũng được nha!`,
      `📞 Bạn có muốn được tư vấn qua điện thoại không? Chia sẻ số của bạn và chúng tôi sẽ liên hệ ngay! Hoặc cứ chat tiếp với tôi cũng được.`,
      `🤝 Để hỗ trợ chuyên sâu hơn, bạn có thể để lại số điện thoại được không? Hoặc cứ tiếp tục trao đổi với tôi ở đây nhé!`,
    ];
    return phoneRequests[Math.floor(Math.random() * phoneRequests.length)];
  }

  // Phone number detection - Enhanced
  const phonePattern = /(\d{10,11}|(\+84|84|0)[0-9]{9,10})/;
  if (phonePattern.test(message)) {
    const thankYouMessages = [
      `🙏 Cảm ơn bạn! Đã nhận số điện thoại của bạn. Chuyên viên sẽ liên hệ trong vòng 30 phút. Tôi có thể hỗ trợ gì thêm không?`,
      `✅ Perfect! Đã ghi nhận số điện thoại. Team tư vấn sẽ gọi cho bạn sớm nhất. Còn câu hỏi gì khác không?`,
      `📝 Đã lưu thông tin! Bạn sẽ nhận được cuộc gọi tư vấn chuyên nghiệp. Trong lúc chờ, cần hỗ trợ gì thêm không?`,
    ];
    return thankYouMessages[
      Math.floor(Math.random() * thankYouMessages.length)
    ];
  }

  // Knowledge-based responses
  let response = "";

  // Product/Service related
  if (
    lowerKnowledge.includes("sản phẩm") ||
    lowerKnowledge.includes("product") ||
    lowerKnowledge.includes("dịch vụ")
  ) {
    if (
      lowerMessage.includes("giá") ||
      lowerMessage.includes("price") ||
      lowerMessage.includes("chi phí")
    ) {
      response = `Về vấn đề giá cả bạn quan tâm, chúng t��i có nhiều gói dịch vụ phù hợp với từng nhu cầu. Để tôi tư vấn chính xác nhất, bạn có thể cho biết quy mô và yêu cầu cụ thể không?`;
    } else if (
      lowerMessage.includes("thông tin") ||
      lowerMessage.includes("tính năng") ||
      lowerMessage.includes("hoạt động")
    ) {
      response = `Dựa trên thông tin bạn cần, tôi có thể giải thích chi tiết về các tính năng và cách thức hoạt động. Bạn muốn tìm hiểu về khía cạnh nào cụ thể?`;
    } else if (
      lowerMessage.includes("so sánh") ||
      lowerMessage.includes("khác biệt")
    ) {
      response = `Để so sánh và tư vấn phù hợp nhất, tôi cần hiểu rõ hơn về nhu cầu c���a bạn. Bạn đang cân nhắc giữa những lựa chọn nào?`;
    }
  }

  // Support related
  if (lowerKnowledge.includes("hỗ trợ") || lowerKnowledge.includes("support")) {
    if (
      lowerMessage.includes("liên hệ") ||
      lowerMessage.includes("contact") ||
      lowerMessage.includes("gọi")
    ) {
      response = `Bạn có thể liên hệ với chúng tôi qua hotline 0792762794 hoặc tiếp tục chat với tôi ở đây. Tôi có thể hỗ trợ ngay để giải quyết vấn đề của bạn.`;
    } else if (
      lowerMessage.includes("cách sử dụng") ||
      lowerMessage.includes("hướng dẫn")
    ) {
      response = `Tôi sẽ hướng dẫn bạn từng bước cách sử dụng. Để hướng dẫn phù hợp, bạn đang gặp khó khăn ở bước nào?`;
    }
  }

  // Business/Company info
  if (
    lowerMessage.includes("công ty") ||
    lowerMessage.includes("doanh nghiệp") ||
    lowerMessage.includes("về chúng tôi")
  ) {
    response = `Chúng tôi là đơn vị chuyên nghiệp với nhiều năm kinh nghiệm trong lĩnh vực này. Bạn muốn tìm hiểu về khía cạnh nào của công ty?`;
  }

  // Technical questions
  if (
    lowerMessage.includes("cách") ||
    lowerMessage.includes("làm sao") ||
    lowerMessage.includes("như thế nào")
  ) {
    response = `Đây là câu hỏi rất hay! Để trả lời chính xác nhất, tôi cần hiểu rõ tình huống cụ thể của bạn. Bạn có thể mô tả chi tiết hơn không?`;
  }

  // Complaint/Problem
  if (
    lowerMessage.includes("lỗi") ||
    lowerMessage.includes("không hoạt động") ||
    lowerMessage.includes("sự cố")
  ) {
    response = `Tôi rất xin lỗi về sự bất tiện n��y. Để hỗ tr�� bạn nhanh nhất, tôi cần biết chi tiết về tình huống bạn đang gặp phải. Bạn có thể mô tả cụ thể hơn không?`;
  }

  // Enhanced default intelligent responses
  if (!response) {
    const contextualResponses = [
      `🤔 Tôi hiểu bạn đang quan tâm đến "${message}". Để tư vấn chính xác nhất, bạn có thể chia sẻ thêm chi tiết không?`,
      `💡 Đây là câu hỏi hay! Về vấn đề này, tôi cần hiểu rõ hơn tình huống cụ thể của bạn để đưa ra lời khuyên phù hợp.`,
      `📚 Cảm ơn bạn đã tin tưởng hỏi tôi! Với chủ đề "${message}", tôi có thể hỗ trợ tốt hơn nếu bạn mô tả chi tiết hơn.`,
      `🎯 Tôi hiểu bạn muốn tìm hiểu về "${message}". Hãy cho tôi biết thêm về nhu cầu cụ thể để tôi tư vấn đúng trọng tâm nhé!`,
      `✨ Đây là vấn đề thú vị! Để đưa ra gợi ý tốt nhất về "${message}", bạn có thể chia sẻ thêm về mục tiêu và ngữ cảnh không?`,
    ];
    response =
      contextualResponses[
        Math.floor(Math.random() * contextualResponses.length)
      ];
  }

  return response;
};

// In-memory customer data storage
const customerData: {
  [sessionId: string]: {
    botId: string;
    messages: Array<{ message: string; response: string; timestamp: string }>;
    phoneNumber?: string;
    email?: string;
    name?: string;
    firstMessage: string;
    lastActive: string;
  };
} = {};

// Test chatbot endpoint (public for widget usage)
export const handleTestChatbot: RequestHandler = async (req, res) => {
  try {
    const { message, botId, knowledge, apiKey, sessionId, botName } = req.body;

    if (!message) {
      return res.status(400).json({ error: "Tin nhắn không được để trống" });
    }

    // Get or create session
    const session =
      sessionId ||
      `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    if (!customerData[session]) {
      customerData[session] = {
        botId: botId || "unknown",
        messages: [],
        firstMessage: message,
        lastActive: new Date().toISOString(),
      };
    }

    const customer = customerData[session];
    customer.lastActive = new Date().toISOString();

    // Check for phone number in message
    const phonePattern = /(\d{10,11}|(\+84|84|0)[0-9]{9,10})/;
    const phoneMatch = message.match(phonePattern);
    if (phoneMatch && !customer.phoneNumber) {
      customer.phoneNumber = phoneMatch[0];
    }

    // Check for email
    const emailPattern = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/;
    const emailMatch = message.match(emailPattern);
    if (emailMatch && !customer.email) {
      customer.email = emailMatch[0];
    }

    try {
      const response = await generateSmartResponse(
        message,
        knowledge,
        botName || "ChatBot AI",
        customer.messages,
        {
          phoneNumber: customer.phoneNumber,
          email: customer.email,
          name: customer.name,
        },
      );

      // Save conversation
      customer.messages.push({
        message,
        response,
        timestamp: new Date().toISOString(),
      });

      res.json({
        success: true,
        response,
        sessionId: session,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error:
          error instanceof Error
            ? error.message
            : "Có lỗi xảy ra khi xử lý tin nhắn",
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Lỗi server",
    });
  }
};

// Check embed status endpoint
export const handleCheckEmbedStatus: RequestHandler = async (req, res) => {
  try {
    const { websiteUrl, botId } = req.body;
    const authHeader = req.headers.authorization;
    const token = authHeader?.replace("Bearer ", "");

    if (!token) {
      return res.status(401).json({ error: "Không có token" });
    }

    // Simulate checking website for embed code
    const isEmbedded = Math.random() > 0.3; // 70% chance of being embedded
    const hasApiKey =
      req.body.apiKey && req.body.apiKey !== "YOUR_CHATGPT_API_KEY";

    let status = "inactive";
    let message = "Mã nhúng chưa được tìm thấy trên website";

    if (isEmbedded && hasApiKey) {
      status = "active";
      message = "Chatbot đang hoạt động bình thường";
    } else if (isEmbedded && !hasApiKey) {
      status = "warning";
      message = "Mã nhúng đã được tìm thấy nhưng thiếu API Key";
    } else if (!isEmbedded && hasApiKey) {
      status = "warning";
      message = "API Key đã cấu hình nhưng mã nhúng chưa được thêm vào website";
    }

    res.json({
      success: true,
      status,
      message,
      websiteUrl,
      lastChecked: new Date().toISOString(),
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Không thể kiểm tra trạng thái embed",
    });
  }
};

// Get customer data for a bot (requires auth)
export const handleGetCustomers: RequestHandler = async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader?.replace("Bearer ", "");

    if (!token) {
      return res.status(401).json({ error: "Không có token" });
    }

    const botId = req.params.botId;

    // Filter customers by botId
    const customers = Object.entries(customerData)
      .filter(([_, customer]) => customer.botId === botId)
      .map(([sessionId, customer]) => ({
        sessionId,
        phoneNumber: customer.phoneNumber,
        email: customer.email,
        name: customer.name,
        firstMessage: customer.firstMessage,
        lastActive: customer.lastActive,
        messageCount: customer.messages.length,
        lastMessage: customer.messages[customer.messages.length - 1]?.message,
      }));

    res.json({ customers });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Lỗi server",
    });
  }
};

// Get conversation history for a customer
export const handleGetConversation: RequestHandler = async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader?.replace("Bearer ", "");

    if (!token) {
      return res.status(401).json({ error: "Không có token" });
    }

    const { sessionId } = req.params;
    const customer = customerData[sessionId];

    if (!customer) {
      return res.status(404).json({ error: "Không tìm thấy cuộc hội thoại" });
    }

    res.json({
      sessionId,
      customer: {
        phoneNumber: customer.phoneNumber,
        email: customer.email,
        name: customer.name,
        firstMessage: customer.firstMessage,
        lastActive: customer.lastActive,
      },
      messages: customer.messages,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Lỗi server",
    });
  }
};
