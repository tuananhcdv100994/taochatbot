import { RequestHandler } from "express";
import { z } from "zod";
import type { User, Bot } from "@shared/api";

// In-memory storage (replace with database in production)
const users: User[] = [
  {
    id: "admin",
    email: "tuananhcdv2021@mail.com",
    password: "Tuananh1994@",
    fullName: "Admin User",
    phoneNumber: "0792762794",
    role: "admin",
    plan: "pro",
    createdAt: new Date().toISOString(),
    botCount: 0,
    messageCount: 0,
  },
];

const bots: Bot[] = [];
const sessions: { [token: string]: string } = {}; // token -> userId

// Validation schemas
const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  fullName: z.string().min(1),
  phoneNumber: z.string().min(10, "Số điện thoại phải có ít nhất 10 số"),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
});

// Helper functions
const generateId = () => Math.random().toString(36).substr(2, 9);
const generateToken = () => Math.random().toString(36).substr(2, 15);

const findUserByEmail = (email: string) => users.find((u) => u.email === email);
const findUserByPhone = (phoneNumber: string) =>
  users.find((u) => u.phoneNumber === phoneNumber);
const findUserById = (id: string) => users.find((u) => u.id === id);
const getUserFromToken = (token: string) => {
  const userId = sessions[token];
  return userId ? findUserById(userId) : null;
};

// Register user
export const handleRegister: RequestHandler = (req, res) => {
  try {
    const { email, password, fullName, phoneNumber } = registerSchema.parse(
      req.body,
    );

    if (findUserByEmail(email)) {
      return res.status(400).json({ error: "Email đã được sử dụng" });
    }

    if (findUserByPhone(phoneNumber)) {
      return res.status(400).json({ error: "Số điện thoại đã được sử dụng" });
    }

    const user: User = {
      id: generateId(),
      email,
      password,
      fullName,
      phoneNumber,
      role: "user",
      plan: "free",
      createdAt: new Date().toISOString(),
      botCount: 0,
      messageCount: 0,
    };

    users.push(user);

    const token = generateToken();
    sessions[token] = user.id;

    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        email: user.email,
        fullName: user.fullName,
        phoneNumber: user.phoneNumber,
        role: user.role,
        plan: user.plan,
        createdAt: user.createdAt,
      },
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        error: "Dữ liệu không hợp lệ",
        details: error.errors,
      });
    }
    res.status(500).json({ error: "Lỗi server" });
  }
};

// Login user
export const handleLogin: RequestHandler = (req, res) => {
  try {
    const { email, password } = loginSchema.parse(req.body);

    const user = findUserByEmail(email);
    if (!user || user.password !== password) {
      return res.status(401).json({ error: "Email hoặc mật khẩu không đúng" });
    }

    const token = generateToken();
    sessions[token] = user.id;

    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        email: user.email,
        fullName: user.fullName,
        phoneNumber: user.phoneNumber,
        role: user.role,
        plan: user.plan,
        createdAt: user.createdAt,
      },
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        error: "Dữ liệu không hợp lệ",
        details: error.errors,
      });
    }
    res.status(500).json({ error: "Lỗi server" });
  }
};

// Logout user
export const handleLogout: RequestHandler = (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.replace("Bearer ", "");

  if (token && sessions[token]) {
    delete sessions[token];
  }

  res.json({ success: true });
};

// Get current user
export const handleGetUser: RequestHandler = (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.replace("Bearer ", "");

  if (!token) {
    return res.status(401).json({ error: "Không có token" });
  }

  const user = getUserFromToken(token);
  if (!user) {
    return res.status(401).json({ error: "Token không hợp lệ" });
  }

  res.json({
    id: user.id,
    email: user.email,
    fullName: user.fullName,
    phoneNumber: user.phoneNumber,
    role: user.role,
    plan: user.plan,
    createdAt: user.createdAt,
  });
};

// Get user bots
export const handleGetUserBots: RequestHandler = (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.replace("Bearer ", "");

  if (!token) {
    return res.status(401).json({ error: "Không có token" });
  }

  const user = getUserFromToken(token);
  if (!user) {
    return res.status(401).json({ error: "Token không hợp lệ" });
  }

  const userBots = bots.filter((bot) => bot.userId === user.id);
  res.json(userBots);
};

// Create bot
export const handleCreateBot: RequestHandler = (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.replace("Bearer ", "");

  if (!token) {
    return res.status(401).json({ error: "Không có token" });
  }

  const user = getUserFromToken(token);
  if (!user) {
    return res.status(401).json({ error: "Token không hợp lệ" });
  }

  const userBots = bots.filter((bot) => bot.userId === user.id);
  if (user.plan === "free" && userBots.length >= 1) {
    return res
      .status(403)
      .json({ error: "Vượt quá giới hạn 1 chatbot. Vui lòng nâng cấp!" });
  }

  const botData = req.body;
  const bot: Bot = {
    id: generateId(),
    userId: user.id,
    name: botData.name,
    description: botData.description,
    knowledge: botData.knowledge,
    gender: botData.gender,
    conversationStyle: botData.conversationStyle,
    primaryColor: botData.primaryColor,
    theme: botData.theme,
    position: botData.position,
    createdAt: new Date().toISOString(),
    apiKey: botData.apiKey || "",
    websiteUrl: botData.websiteUrl || "",
  };

  bots.push(bot);
  res.json({ success: true, bot });
};

// Update bot
export const handleUpdateBot: RequestHandler = (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.replace("Bearer ", "");

  if (!token) {
    return res.status(401).json({ error: "Không có token" });
  }

  const user = getUserFromToken(token);
  if (!user) {
    return res.status(401).json({ error: "Token không hợp lệ" });
  }

  const botId = req.params.id;
  const bot = bots.find((bot) => bot.id === botId && bot.userId === user.id);

  if (!bot) {
    return res.status(404).json({ error: "Không tìm thấy bot" });
  }

  Object.assign(bot, req.body);
  res.json({ success: true, bot });
};

// Delete bot
export const handleDeleteBot: RequestHandler = (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.replace("Bearer ", "");

  if (!token) {
    return res.status(401).json({ error: "Không có token" });
  }

  const user = getUserFromToken(token);
  if (!user) {
    return res.status(401).json({ error: "Token không hợp lệ" });
  }

  const botId = req.params.id;
  const botIndex = bots.findIndex(
    (bot) => bot.id === botId && bot.userId === user.id,
  );

  if (botIndex === -1) {
    return res.status(404).json({ error: "Không tìm thấy bot" });
  }

  bots.splice(botIndex, 1);
  res.json({ success: true });
};

// Get bot embed code
export const handleGetBotEmbed: RequestHandler = (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.replace("Bearer ", "");

  if (!token) {
    return res.status(401).json({ error: "Không có token" });
  }

  const user = getUserFromToken(token);
  if (!user) {
    return res.status(401).json({ error: "Token không hợp lệ" });
  }

  const botId = req.params.id;
  const bot = bots.find((bot) => bot.id === botId && bot.userId === user.id);

  if (!bot) {
    return res.status(404).json({ error: "Không tìm thấy bot" });
  }

  const serverUrl =
    process.env.NODE_ENV === "production"
      ? "https://your-domain.com"
      : "http://localhost:8080";

  // Script Widget Embed Code (Recommended) - No API key needed!
  const scriptEmbedCode = `<!-- ChatBot AI Widget Script (Recommended) - Paste before closing </body> tag -->
<!-- No API Key required - Powered by Google Gemini AI -->
<script 
  src="${serverUrl}/widget/chatbot.js"
  data-bot-id="${bot.id}"
  data-bot-name="${bot.name}"  
  data-primary-color="${bot.primaryColor}"
  data-theme="${bot.theme}"
  data-position="${bot.position}"
  data-server-url="${serverUrl}">
</script>`;

  // Iframe Widget Embed Code (Backup) - No API key needed!
  const iframeEmbedCode = `<!-- ChatBot AI Widget (iframe) - Paste before closing </body> tag -->
<!-- No API Key required - Powered by Google Gemini AI -->
<iframe
  id="chatbot-ai-iframe"
  src="${serverUrl}/iframe-widget?botId=${bot.id}&botName=${encodeURIComponent(bot.name)}&primaryColor=${encodeURIComponent(bot.primaryColor)}&theme=${bot.theme}&position=${bot.position}"
    style="position: fixed; bottom: 0; right: 0; width: 400px; height: 600px; border: none; z-index: 999999; background: transparent;"
  allow="microphone; camera"
  sandbox="allow-same-origin allow-scripts allow-forms allow-popups"
  loading="lazy">
</iframe>

<script>
// Auto-resize iframe based on content
(function() {
  var iframe = document.getElementById('chatbot-ai-iframe');
  if (!iframe) return;

  // Make iframe responsive on mobile
  function adjustIframe() {
    if (window.innerWidth < 450) {
      iframe.style.width = '100vw';
      iframe.style.right = '0';
      iframe.style.left = '0';
    } else {
      iframe.style.width = '400px';
      iframe.style.right = '0';
      iframe.style.left = 'auto';
    }
  }

  // Adjust on load and resize
  adjustIframe();
  window.addEventListener('resize', adjustIframe);

  console.log('ChatBot AI iframe loaded successfully');
})();
</script>`;

  res.json({
    embedCode: scriptEmbedCode, // Default to script widget
    scriptEmbedCode,
    iframeEmbedCode,
  });
};

// Admin: Get all users
export const handleGetAllUsers: RequestHandler = (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.replace("Bearer ", "");

  if (!token) {
    return res.status(401).json({ error: "Không có token" });
  }

  const user = getUserFromToken(token);
  if (!user || user.role !== "admin") {
    return res.status(403).json({ error: "Không có quyền truy cập" });
  }

  const usersWithStats = users.map((u) => ({
    id: u.id,
    email: u.email,
    fullName: u.fullName,
    phoneNumber: u.phoneNumber,
    role: u.role,
    plan: u.plan,
    createdAt: u.createdAt,
    botCount: bots.filter((b) => b.userId === u.id).length,
    messageCount: u.messageCount,
  }));

  res.json(usersWithStats);
};

// Admin: Update user plan
export const handleUpdateUserPlan: RequestHandler = (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.replace("Bearer ", "");

  if (!token) {
    return res.status(401).json({ error: "Không có token" });
  }

  const admin = getUserFromToken(token);
  if (!admin || admin.role !== "admin") {
    return res.status(403).json({ error: "Không có quyền truy cập" });
  }

  const userId = req.params.id;
  const { plan } = req.body;

  const user = findUserById(userId);
  if (!user) {
    return res.status(404).json({ error: "Không tìm thấy user" });
  }

  user.plan = plan;
  res.json({ success: true });
};

// Admin: Delete user
export const handleDeleteUser: RequestHandler = (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.replace("Bearer ", "");

  if (!token) {
    return res.status(401).json({ error: "Không có token" });
  }

  const admin = getUserFromToken(token);
  if (!admin || admin.role !== "admin") {
    return res.status(403).json({ error: "Không có quyền truy cập" });
  }

  const userId = req.params.id;
  const userIndex = users.findIndex((u) => u.id === userId);

  if (userIndex === -1) {
    return res.status(404).json({ error: "Không tìm thấy user" });
  }

  // Also delete user's bots
  const userBotIndices = bots
    .map((bot, index) => (bot.userId === userId ? index : -1))
    .filter((index) => index !== -1)
    .reverse(); // Reverse to delete from end to avoid index issues

  userBotIndices.forEach((index) => bots.splice(index, 1));

  // Delete user tokens
  Object.keys(sessions).forEach((token) => {
    if (sessions[token] === userId) {
      delete sessions[token];
    }
  });

  users.splice(userIndex, 1);
  res.json({ success: true });
};
